# Nefeon Careers — architecture

```mermaid
flowchart TD
  A[Applicant browser] --> B[Next.js five-step application form]
  B --> C[POST /api/applications/upload-ticket]
  C --> D[Supabase server creates upload ticket + signed upload token]
  D --> E[Browser uploads PDF directly to private Supabase Storage]
  B --> F[POST /api/applications]
  F --> G[Validate fields, consent, ticket, expiry, email, PDF signature]
  G --> H[(Supabase Postgres: applications)]
  G --> I[(Private Storage: resumes)]
  H --> J[Resend application receipt]
  H --> K[Resend team notification]
  L[Owner / HR / manager] --> M[Next.js creates OTP and sends through Resend API]
  M --> N[OTP stored as HMAC hash in Supabase Postgres]
  N --> N2[Verify OTP; issue HttpOnly session cookie]
  N2 --> O[Protected API + staff allowlist and session check]
  O --> H
  O --> I
  O --> P[Fill supplied NEFEON offer-letter PDF]
  P --> R[(Private Storage: offer PDF)]
  P --> S[Resend secure 14-day offer link]
  S --> T[Candidate downloads, signs and uploads PDF]
  T --> U[(Private Storage: signed offer)]
  U --> V[Update offer/application status + audit event]
  V --> W[Resend HR notification]
```

## Components

- `app/page.tsx`: public careers page and 5-step application form.
- `app/api/applications/upload-ticket/route.ts`: validates the email/file metadata, creates a 20-minute upload ticket in Postgres and creates a Supabase signed upload token for a random private path.
- `app/api/applications/route.ts`: validates all applicant fields and required consents, verifies the ticket belongs to the submitted email and has not expired or been consumed, checks private storage object size and PDF magic bytes, inserts the application, then sends Resend emails.
- `app/api/admin/request-otp/route.ts`: checks the exact staff allowlist and sends a generated one-time code directly through the Resend API; stores only an HMAC of the code in Supabase Postgres.
- `app/api/admin/verify-otp/route.ts`: validates one-time code expiry and attempts, then issues an eight-hour HttpOnly session cookie backed by a hashed session token in the database.
- `app/api/admin/session/route.ts` and `app/api/admin/signout/route.ts`: validate and revoke application-managed staff sessions.
- `lib/staff-auth.ts`: verifies the application-owned cookie session and current staff allowlist; it does not call Supabase Auth.
- `app/api/admin/applications/route.ts`: protected list, search, filter and update routes.
- `app/api/admin/applications/[id]/resume/route.ts`: streams a CV only after staff authorization; it never returns a public storage URL.
- `app/api/admin/send-offer/route.ts`: validates selected status and HR-entered fields, fills the supplied PDF with PDF-lib, stores it in private Storage, and sends a time-limited candidate portal link.
- `lib/email.ts`: HTML templates for application, offer-link, signed-offer receipt and onboarding notifications.
- `lib/offer-pdf.ts`: fills the provided two-page PDF template; the static company signature/stamp remains from the source PDF.
- `app/offer/[token]`: candidate portal for downloading the personalized offer PDF and uploading the signed copy.
- `supabase/migrations/0003_offer_letters.sql`: private offer records/bucket plus atomic signed-offer acceptance and audit updates.
- `supabase/migrations`: database schema, RLS grants, private Storage bucket and upload tickets.

## Security boundaries

- The browser sees only the Supabase publishable/anon key and a single-use signed upload token, never the service-role key.
- Application records, audit events and upload ticket rows deny direct `anon` and `authenticated` table access through RLS and grants; trusted API routes use the service-role key after validation/authorization.
- The resume, offer-letter and signed-offer buckets are private. Document downloads use authenticated routes or short-lived server-generated URLs; files are not public links.
- Authenticated dashboard API routes verify the Supabase session with the server client and check the staff email allowlist on every call.
- Form submissions require both accuracy and privacy acknowledgments. Server-side validation is repeated even when the browser validates fields.
- Upload tickets expire, are tied to the expected applicant email, and can be consumed by a single application record. The server validates PDF magic bytes and the size reported for the upload.

## Limitations and production work

The included per-process rate maps are a starter guard, not distributed protection. Use a shared limiter and WAF/bot protection at public launch. Add scheduled cleanup for expired upload tickets/orphaned files, and implement retention/deletion jobs once the final policy is decided. Admin OTP, applicant notices, offer letters and onboarding emails are sent directly by the Resend API. Supabase Auth email delivery/SMTP is not used by the admin login flow. Supabase remains the Postgres/private Storage provider. A successful email API response means accepted for delivery, not guaranteed inbox placement; monitor provider logs.
