import 'server-only';

/**
 * Resolve the public base URL used in email links. In production this must be
 * explicitly configured so candidate emails never contain localhost links.
 */
export function getCareersPublicUrl(requestOrigin: string): string {
  const configured = process.env.CAREERS_PUBLIC_URL?.trim();
  const isProduction = process.env.NODE_ENV === 'production';
  const value = configured || (isProduction ? '' : requestOrigin);

  if (!value) {
    throw new Error('CAREERS_PUBLIC_URL must be set to the public HTTPS URL of the deployed careers app.');
  }

  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new Error('CAREERS_PUBLIC_URL must be a valid absolute URL.');
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error('CAREERS_PUBLIC_URL must use HTTP or HTTPS.');
  }
  if (isProduction && parsed.protocol !== 'https:') {
    throw new Error('CAREERS_PUBLIC_URL must use HTTPS in production. Set it to your Render service URL.');
  }
  if (isProduction && ['localhost', '127.0.0.1', '0.0.0.0'].includes(parsed.hostname)) {
    throw new Error('CAREERS_PUBLIC_URL cannot be localhost in production. Set it to your public Render service URL.');
  }

  return parsed.origin.replace(/\/$/, '');
}
