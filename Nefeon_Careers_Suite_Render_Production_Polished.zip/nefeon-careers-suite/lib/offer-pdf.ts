import 'server-only';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { PDFDocument, StandardFonts, rgb, type PDFPage, type PDFFont } from 'pdf-lib';

export type OfferLetterFields = {
  issueDate: string;
  role: string;
  reportingTo: string;
  startDate: string;
  endDate: string;
  workingDays: string;
  startTime: string;
  endTime: string;
  hoursPerWeek: string;
  acceptanceDeadline: string;
};

const TEMPLATE_PATH = path.join(process.cwd(), 'templates', 'NEFEON_Internship_Offer_Letter_template.pdf');
const INK = rgb(0.08, 0.08, 0.16);
const BRAND_GREEN = rgb(0.19, 0.36, 0.26);
const WHITE = rgb(1, 1, 1);

function pdfSafe(value: string) {
  // Standard PDF fonts support WinAnsi rather than every Unicode script.
  return value.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[–—]/g, '-').replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/[^\x20-\xFF]/g, '?').trim();
}

function cover(page: PDFPage, x: number, top: number, width: number, height: number, color = WHITE) {
  page.drawRectangle({ x, y: page.getHeight() - top - height, width, height, color, opacity: 1 });
}

function drawTop(page: PDFPage, text: string, x: number, baselineTop: number, font: PDFFont, size: number, color = INK) {
  page.drawText(pdfSafe(text), { x, y: page.getHeight() - baselineTop, font, size, color });
}

function drawFit(page: PDFPage, text: string, x: number, baselineTop: number, maxWidth: number, font: PDFFont, maxSize = 8.64, minSize = 6.5, color = BRAND_GREEN) {
  const safe = pdfSafe(text);
  let size = maxSize;
  while (size > minSize && font.widthOfTextAtSize(safe, size) > maxWidth) size -= 0.2;
  if (font.widthOfTextAtSize(safe, size) > maxWidth) throw new Error('One of the offer-letter fields is too long for the provided PDF template. Shorten the field and try again.');
  drawTop(page, safe, x, baselineTop, font, size, color);
}

function formatDate(value: string) {
  const date = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new Error('Offer-letter dates must be valid calendar dates.');
  return `${String(date.getUTCDate()).padStart(2, '0')}/${String(date.getUTCMonth() + 1).padStart(2, '0')}/${date.getUTCFullYear()}`;
}

export async function makeOfferLetterPdf(fields: OfferLetterFields, candidateName: string) {
  const templateBytes = await readFile(TEMPLATE_PATH);
  const pdf = await PDFDocument.load(templateBytes);
  if (pdf.getPageCount() < 2) throw new Error('The NEFEON internship offer-letter template must contain both pages.');
  const [page1, page2] = pdf.getPages();
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const date = formatDate(fields.issueDate);
  const start = formatDate(fields.startDate);
  const end = formatDate(fields.endDate);
  const deadline = formatDate(fields.acceptanceDeadline);
  const name = pdfSafe(candidateName);
  const role = pdfSafe(fields.role);
  const reportingTo = pdfSafe(fields.reportingTo);
  const workingHours = `${fields.workingDays}, ${fields.startTime} to ${fields.endTime}, ${fields.hoursPerWeek} hours/week`;

  // Replace the variable fields while retaining the supplied template, branding and company signature/stamp.
  cover(page1, 64, 157, 115, 13.8);
  drawFit(page1, date, 66.4, 166.51, 105, regular, 8.64, 7.5);

  cover(page1, 44, 175, 275, 14.2);
  drawFit(page1, `Dear ${name},`, 45, 184.37, 270, regular, 8.64, 7.0, INK);

  cover(page1, 352, 192.5, 194, 14.2);
  drawFit(page1, `${role}.`, 354.8, 202.23, 188, regular, 8.64, 6.7, BRAND_GREEN);

  // Replace project-specific company marketing copy with a neutral company introduction.
  cover(page1, 44, 240.5, 511, 178.5);
  const generalAbout = [
    'NEFEON TECHNOLOGY is a technology-focused organization committed to practical, user-friendly solutions.',
    'We value innovation, collaboration, continuous learning and responsible problem-solving.',
    'Our team encourages clear communication, curiosity, respect and a strong focus on quality.',
    'We aim to create an inclusive environment where team members can learn, share ideas and improve their skills.',
    'Interns work with their assigned supervisor and contribute to agreed role responsibilities and shared goals.',
    'The organization encourages thoughtful planning, progress updates and responsible use of company resources.',
    'Team members are expected to communicate respectfully, meet agreed deadlines and ask questions when support is needed.',
    'Feedback and collaboration help interns strengthen professional skills and build confidence in their work.',
    'We value confidentiality, integrity and care for information shared during the internship.',
  ];
  [254.5, 271.5, 288.5, 305.5, 322.5, 339.5, 356.5, 373.5, 390.5].forEach((baseline, index) => drawFit(page1, generalAbout[index], 45, baseline, 498, regular, 8.55, 7.2, INK));

  const tableFields: Array<{ text: string; top: number; height: number; baseline: number; maxWidth: number; size?: number; shaded?: boolean }> = [
    { text: role, top: 449, height: 23.5, baseline: 466.69, maxWidth: 292 },
    { text: reportingTo, top: 472.5, height: 23.5, baseline: 489.16, maxWidth: 292, shaded: true },
    { text: start, top: 496, height: 23.5, baseline: 511.63, maxWidth: 292 },
    { text: end, top: 518.5, height: 23.5, baseline: 534.10, maxWidth: 292, shaded: true },
    { text: workingHours, top: 562.5, height: 23.5, baseline: 579.04, maxWidth: 292, size: 8.4, shaded: true },
  ];
  const x = 251.5;
  const zebra = rgb(0.965, 0.977, 0.965);
  for (const item of tableFields) {
    cover(page1, 250, item.top, 300, item.height, item.shaded ? zebra : WHITE);
    drawFit(page1, item.text, x, item.baseline, item.maxWidth, regular, item.size ?? 8.64, 6.6);
  }

  cover(page1, 54, 754.8, 484, 14.2);
  drawFit(page1, 'All original work you create for NEFEON during the internship belongs to the Company.', 56.5, 764.56, 475, regular, 8.64, 7.0, INK);

  cover(page2, 44, 340.5, 511, 20.5);
  drawFit(page2, `sign and return a soft copy by ${deadline}. We look forward to welcoming you.`, 45, 353.18, 498, regular, 8.64, 7.0, INK);

  // Populate the intern's printed name beside the blank acceptance label; the intern still adds their own signature and signing date.
  cover(page2, 324, 483.6, 205, 13.2);
  drawFit(page2, name, 326.5, 492.85, 198, regular, 8.3, 6.7, BRAND_GREEN);

  // Populate the company-side offer date beside the existing signed/stamped company block.
  drawFit(page2, date, 68.5, 525.34, 75, regular, 8.06, 7.0, INK);

  return pdf.save({ useObjectStreams: false });
}
