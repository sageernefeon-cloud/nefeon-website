import 'server-only';
import { createHash } from 'node:crypto';
import { NextRequest } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';

export type StaffRole = 'owner' | 'hr' | 'manager';
export type StaffIdentity = { id: string; email: string; role: StaffRole };
const SESSION_COOKIE = 'nefeon_staff_session';
function sha256(value: string) { return createHash('sha256').update(value).digest('hex'); }

export function staffAllowlist(): Map<string, StaffRole> {
  const result = new Map<string, StaffRole>();
  for (const item of (process.env.STAFF_EMAILS ?? '').split(',')) {
    const [rawEmail, rawRole] = item.trim().split(':');
    const email = (rawEmail ?? '').trim().toLowerCase();
    const role = (rawRole ?? 'manager').trim().toLowerCase();
    if (email && (role === 'owner' || role === 'manager' || role === 'hr')) result.set(email, role as StaffRole);
  }
  return result;
}

export function isAllowedStaffEmail(email: string) { return staffAllowlist().has(email.trim().toLowerCase()); }

export async function requireStaff(request: NextRequest): Promise<StaffIdentity> {
  const token = request.cookies.get(SESSION_COOKIE)?.value ?? '';
  if (!token || token.length < 40) throw new Error('Please sign in again.');
  const tokenHash = sha256(token);
  const supabase = getSupabaseAdmin();
  const { data: session, error } = await supabase.from('staff_sessions')
    .select('id, email, role, expires_at, revoked_at')
    .eq('token_hash', tokenHash).is('revoked_at', null).gt('expires_at', new Date().toISOString()).maybeSingle();
  if (error || !session?.email) throw new Error('Your session is invalid or has expired.');
  const email = String(session.email).toLowerCase();
  const currentRole = staffAllowlist().get(email);
  if (!currentRole) throw new Error('This email is not authorized to access the Nefeon careers dashboard.');
  return { id: session.id, email, role: currentRole };
}

export function jsonErrorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Unexpected server error.';
}
