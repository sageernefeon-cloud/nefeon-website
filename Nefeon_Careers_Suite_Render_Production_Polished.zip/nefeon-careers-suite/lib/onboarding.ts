import 'server-only';
import { createHash } from 'node:crypto';

export const ONBOARDING_BUCKET = 'nefeon-onboarding-documents';
export const MAX_ONBOARDING_FILE_BYTES = 8 * 1024 * 1024;
export const REQUIRED_ONBOARDING_DOCUMENTS = ['aadhaar', 'passport_photo', 'education_proof'] as const;
export type OnboardingDocumentType = typeof REQUIRED_ONBOARDING_DOCUMENTS[number] | 'pan_card' | 'other_document';

export const ONBOARDING_DOCUMENTS: Record<OnboardingDocumentType, { label: string; required: boolean; accepts: string }> = {
  aadhaar: { label: 'Aadhaar card (masked Aadhaar preferred where accepted)', required: true, accepts: '.pdf,.jpg,.jpeg,.png' },
  passport_photo: { label: 'Passport-size photo', required: true, accepts: '.jpg,.jpeg,.png' },
  education_proof: { label: 'Education / college proof', required: true, accepts: '.pdf,.jpg,.jpeg,.png' },
  signed_offer: { label: 'Signed offer letter (already collected separately)', required: false, accepts: '.pdf' },
  pan_card: { label: 'PAN card (only if required for the engagement)', required: false, accepts: '.pdf,.jpg,.jpeg,.png' },
  other_document: { label: 'Additional supporting document (optional)', required: false, accepts: '.pdf,.jpg,.jpeg,.png' },
};

export function hashOnboardingToken(token: string) {
  return createHash('sha256').update(token).digest('hex');
}

export function isAllowedOnboardingMime(documentType: OnboardingDocumentType, mime: string) {
  if (!['application/pdf', 'image/jpeg', 'image/png'].includes(mime)) return false;
  if (documentType === 'passport_photo') return mime === 'image/jpeg' || mime === 'image/png';
  return true;
}

export function looksLikeFileType(bytes: Uint8Array, mime: string) {
  if (mime === 'application/pdf') return bytes.length >= 5 && String.fromCharCode(...bytes.slice(0, 5)) === '%PDF-';
  if (mime === 'image/jpeg') return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  if (mime === 'image/png') return bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 && bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a;
  return false;
}
