import 'server-only';
import { createHash } from 'node:crypto';
import { getSupabaseAdmin } from '@/lib/supabase-server';

export const OFFER_BUCKET = 'nefeon-offer-letters';
export const OFFER_LINK_LIFETIME_DAYS = 14;
export const MAX_SIGNED_OFFER_BYTES = 8 * 1024 * 1024;

export function hashOfferToken(token: string) {
  return createHash('sha256').update(token).digest('hex');
}

export async function findOfferByToken(token: string) {
  if (!token || token.length < 32 || token.length > 200 || !/^[A-Za-z0-9_-]+$/.test(token)) return { supabase: getSupabaseAdmin(), offer: null, error: null };
  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase.from('offer_letters').select('*').eq('token_hash', hashOfferToken(token)).maybeSingle();
  if (error) return { supabase, offer: null, error };
  if (!data) return { supabase, offer: null, error: null };
  if (data.status === 'sent' && new Date(data.expires_at).getTime() <= Date.now()) {
    const { data: expired, error: expireError } = await supabase.from('offer_letters').update({ status: 'expired', updated_at: new Date().toISOString() }).eq('id', data.id).eq('status', 'sent').select('*').single();
    if (expireError) return { supabase, offer: data, error: expireError };
    return { supabase, offer: expired, error: null };
  }
  return { supabase, offer: data, error: null };
}

export function looksLikePdf(bytes: Uint8Array) {
  return bytes.length >= 5 && String.fromCharCode(...bytes.slice(0, 5)) === '%PDF-';
}
