import 'server-only';
import { Resend } from 'resend';

const BRAND = '#315c43';
const BRAND_DARK = '#234733';

function getResend() {
  if (!process.env.RESEND_API_KEY) throw new Error('RESEND_API_KEY is not configured.');
  return new Resend(process.env.RESEND_API_KEY);
}

function fromAddress() {
  const from = process.env.EMAIL_FROM?.trim();
  if (!from) throw new Error('EMAIL_FROM is not configured. Use an address on your verified sending domain.');
  const plainEmail = /^[^<>\s]+@[^<>\s]+\.[^<>\s]+$/;
  const namedEmail = /^[^<>]+<[^<>\s]+@[^<>\s]+\.[^<>\s]+>$/;
  if (!plainEmail.test(from) && !namedEmail.test(from)) {
    throw new Error('EMAIL_FROM must look like careers@nefeon.site or Nefeon Careers <careers@nefeon.site>.');
  }
  return from;
}

export async function sendStaffLoginOtpEmail(to: string, otp: string) {
  const resend = getResend();
  const content = `
    <p>Use this code to sign in to the Nefeon Careers team workspace.</p>
    <div style="margin:24px 0;padding:20px 16px;border:1px solid #dce6dd;border-radius:10px;background:#f5f8f5;color:${BRAND_DARK};font-size:32px;font-weight:750;letter-spacing:9px;text-align:center">${escapeHtml(otp)}</div>
    <p>This code expires in <strong>10 minutes</strong> and can be used once. If you did not request it, you can ignore this email.</p>
    <p style="font-size:13px;color:#647166">For your security, never share this code with anyone.</p>`;
  const result = await resend.emails.send({
    from: fromAddress(), to, subject: 'Your Nefeon Careers sign-in code', html: emailShell('Sign-in code', content),
  });
  if (result.error) throw new Error(`Resend could not send the sign-in email: ${result.error.message}`);
  return result.data;
}

export function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char] ?? char);
}

function emailShell(title: string, content: string) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head><body style="margin:0;padding:28px 12px;background:#f4f6f3;color:#27342b;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:antialiased">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse"><tr><td align="center">
  <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="width:100%;max-width:600px;border:1px solid #e1e7e1;border-radius:12px;overflow:hidden;background:#ffffff;border-collapse:separate;border-spacing:0">
  <tr><td style="padding:24px 30px 21px;border-bottom:1px solid #e9eee9">
    <div style="color:${BRAND};font-size:14px;font-weight:800;letter-spacing:2.5px">NEFEON</div>
    <div style="margin-top:5px;color:#7a867d;font-size:11px;letter-spacing:.4px">CAREERS</div>
    <h1 style="margin:22px 0 0;color:#202b24;font-size:23px;line-height:1.3;font-weight:700">${escapeHtml(title)}</h1>
  </td></tr>
  <tr><td style="padding:25px 30px 28px;color:#4e5d52;font-size:14px;line-height:1.75">${content}</td></tr>
  <tr><td style="padding:17px 30px;border-top:1px solid #e9eee9;color:#7c877e;font-size:11px;line-height:1.7">Nefeon Careers · Bengaluru, India<br/>For help, contact <a href="mailto:${escapeHtml(process.env.CAREERS_NOTIFICATION_EMAIL || 'team.nefeon@gmail.com')}" style="color:${BRAND};text-decoration:underline">${escapeHtml(process.env.CAREERS_NOTIFICATION_EMAIL || 'team.nefeon@gmail.com')}</a>.</td></tr>
  </table></td></tr></table></body></html>`;
}

function emailButton(label: string, url: string) {
  const safeUrl = escapeHtml(url);
  const safeLabel = escapeHtml(label);
  return `<table role="presentation" cellspacing="0" cellpadding="0" style="margin:22px 0 12px;border-collapse:separate"><tr><td bgcolor="${BRAND}" style="border-radius:7px;background:${BRAND}"><a href="${safeUrl}" style="display:inline-block;padding:13px 19px;border:1px solid ${BRAND};border-radius:7px;background:${BRAND};color:#ffffff;text-decoration:none;font-size:13px;font-weight:700">${safeLabel}</a></td></tr></table><p style="margin:0 0 20px;color:#7a867d;font-size:11px;line-height:1.7">If the button does not open, use this <a href="${safeUrl}" style="color:${BRAND};text-decoration:underline">secure link</a>.</p>`;
}

export async function sendApplicantConfirmation(to: string, name: string, role: string, submissionId: string) {
  const resend = getResend();
  const content = `<p>Hello ${escapeHtml(name || 'there')},</p>
    <p>Thank you for applying to Nefeon. We have received your internship application.</p>
    ${role ? `<p><strong>Role selected:</strong> ${escapeHtml(role)}</p>` : ''}
    <p>The team will review your application and contact you if there is a next step. This email confirms receipt only; it is not an offer of internship.</p>
    <div style="margin:20px 0;padding:14px 16px;border:1px solid #e1e8e1;border-radius:8px;background:#f8faf8"><div style="color:#78847b;font-size:10px;font-weight:700;letter-spacing:.7px">APPLICATION REFERENCE</div><div style="margin-top:5px;color:${BRAND_DARK};font-size:16px;font-weight:750;letter-spacing:.3px">${escapeHtml(submissionId)}</div></div>
    <p>Regards,<br/>Nefeon Careers Team</p>`;
  const result = await resend.emails.send({ from: fromAddress(), to, subject: 'Nefeon Careers — application received', html: emailShell('Application received', content) });
  return result;
}

export async function sendTeamNotification(to: string, name: string, email: string, role: string, submissionId: string, dashboardUrl: string) {
  const resend = getResend();
  const content = `<p>A new internship application has been submitted.</p>
    <div style="margin:18px 0;padding:15px;border:1px solid #e1e8e1;border-radius:8px;background:#f8faf8">
      <p style="margin:0 0 8px"><strong>Applicant</strong><br/>${escapeHtml(name || 'Not provided')}</p>
      <p style="margin:0 0 8px"><strong>Email</strong><br/><a href="mailto:${escapeHtml(email)}" style="color:${BRAND}">${escapeHtml(email || 'Not provided')}</a></p>
      <p style="margin:0 0 8px"><strong>Role</strong><br/>${escapeHtml(role || 'Not provided')}</p>
      <p style="margin:0"><strong>Reference</strong><br/>${escapeHtml(submissionId)}</p>
    </div>
    ${emailButton('Open careers dashboard', dashboardUrl)}
    <p style="font-size:12px;color:#758178">Review the application and resume from the protected team workspace. Do not forward candidate documents by email.</p>`;
  return resend.emails.send({ from: fromAddress(), to, subject: `New application — ${name || 'Candidate'} · Nefeon Careers`, html: emailShell('New application', content) });
}

export async function sendOfferLinkEmail(to: string, applicantName: string, role: string, offerUrl: string, expiresAt: string) {
  const resend = getResend();
  const deadline = new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeZone: 'Asia/Kolkata' }).format(new Date(expiresAt));
  const content = `<p>Dear ${escapeHtml(applicantName || 'Applicant')},</p>
    <p>Your Nefeon internship offer for <strong>${escapeHtml(role)}</strong> is ready to review.</p>
    <p>Open the secure portal to download the PDF. Review the terms, sign the document using a PDF editor or by printing and signing it, then return to the same portal to upload the signed copy.</p>
    ${emailButton('Review offer letter', offerUrl)}
    <p style="font-size:12px;color:#68756b">This link expires on <strong>${escapeHtml(deadline)} (India time)</strong>. If any detail looks incorrect, please contact the Nefeon Careers Team before signing.</p>
    <p>Please upload only the signed offer through this portal. Do not email identity documents or share Aadhaar OTPs or biometric information.</p>
    <p>Regards,<br/>Nefeon Careers Team</p>`;
  return resend.emails.send({ from: fromAddress(), to, subject: `Your Nefeon internship offer — ${role}`, html: emailShell('Internship offer letter', content) });
}

export async function sendSignedOfferReceivedEmail(to: string, applicantName: string, role: string, dashboardUrl: string) {
  const resend = getResend();
  const content = `<p>A candidate has returned a signed internship offer through the private portal.</p>
    <div style="margin:18px 0;padding:15px;border:1px solid #e1e8e1;border-radius:8px;background:#f8faf8"><p style="margin:0 0 8px"><strong>Candidate</strong><br/>${escapeHtml(applicantName || 'Not provided')}</p><p style="margin:0"><strong>Role</strong><br/>${escapeHtml(role || 'Not provided')}</p></div>
    ${emailButton('Review signed offer', dashboardUrl)}
    <p style="font-size:12px;color:#68756b">The signed PDF is stored privately. Open the candidate record in the dashboard to review or download it; the document is not attached to this email.</p>
    <p>Regards,<br/>Nefeon Careers Team</p>`;
  return resend.emails.send({ from: fromAddress(), to, subject: `Signed offer received — ${applicantName || 'Candidate'}`, html: emailShell('Signed offer received', content) });
}

export async function sendOnboardingRequestEmail(to: string, applicantName: string, role: string, onboardingUrl: string, expiresAt: string) {
  const resend = getResend();
  const deadline = new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }).format(new Date(expiresAt));
  const content = `<p>Hello ${escapeHtml(applicantName || 'there')},</p>
    <p>You have reached the final onboarding stage for your Nefeon ${escapeHtml(role || 'internship')} opportunity.</p>
    <p>Please use the secure portal below to submit the requested details and documents. Your signed offer has already been collected separately.</p>
    ${emailButton('Open onboarding form', onboardingUrl)}
    <div style="margin:16px 0;padding:14px 16px;border:1px solid #e1e8e1;border-radius:8px;background:#f8faf8"><strong>Documents requested</strong><ul style="margin:8px 0 0;padding-left:20px"><li>Identity proof accepted for the stated purpose</li><li>Recent passport-size photograph</li><li>Education or college proof</li></ul></div>
    <p>Upload files only through this secure portal; do not reply with identity documents attached. Where accepted for the purpose, a masked Aadhaar is preferred. Never share Aadhaar OTPs or biometric information.</p>
    <p style="font-size:12px;color:#68756b">The link expires on <strong>${escapeHtml(deadline)} (India time)</strong>. Contact the Nefeon Careers Team if you need help before it expires.</p>
    <p>Regards,<br/>Nefeon Careers Team</p>`;
  return resend.emails.send({ from: fromAddress(), to, subject: 'Nefeon Careers — final onboarding', html: emailShell('Final onboarding', content) });
}
