# Nefeon Careers Suite

A Next.js application for internship applications, recruitment review, offer letters and final-stage onboarding. Applicant emails and team OTPs are delivered through the Resend API. Supabase is used for the database and private document storage.

## Run locally

Requirements: Node.js 20.9 or newer; Node 22 LTS is recommended.

```powershell
npm install
Copy-Item .env.example .env.local
notepad .env.local
npm run typecheck
npm run build
npm run dev
```

Open `http://localhost:3000`. The admin login is at `/admin/login`.

Set real values in `.env.local`:

- `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`: browser-safe Supabase project URL and publishable/anon key.
- `SUPABASE_SERVICE_ROLE_KEY`: server-only Supabase secret. Never expose it through a `NEXT_PUBLIC_` variable or commit it.
- `STAFF_EMAILS`: exact email/role pairs, e.g. `owner@nefeon.site:owner,hr@nefeon.site:hr`. Supported role labels are `owner`, `hr` and `manager`.
- `STAFF_OTP_SECRET`: generate with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`.
- `RESEND_API_KEY` and `EMAIL_FROM`: use a valid Resend API key and an address on the verified sending domain, e.g. `Nefeon Careers <careers@nefeon.site>`.
- `CAREERS_NOTIFICATION_EMAIL`: team inbox for new applications and signed-offer alerts.
- `CAREERS_PUBLIC_URL`: locally `http://localhost:3000`; on Render, use the exact public HTTPS URL assigned to your deployed service. Production offer and onboarding links will not be generated from localhost or an HTTP URL.
- `COMPANY_LEGAL_NAME` and `COMPANY_ADDRESS`: confirm the legal/trading details before sending official documents.
- `PRIVACY_NOTICE_VERSION` and `APPLICANT_DATA_RETENTION_MONTHS`: align these with the privacy notice and your actual records process.

This project uses a custom, server-verified Resend OTP flow for staff; Supabase Auth users and Supabase Auth SMTP are not required for admin login. Supabase remains the database and private Storage service.

## Supabase database setup

Use the same Supabase project URL as the app's environment variables. Back up the project before applying migrations.

For a fresh database, run the SQL files in `supabase/migrations` in order:

1. `0001_initial_schema.sql`
2. `0002_final_onboarding.sql`
3. `0003_offer_letters.sql`
4. `0004_resend_staff_auth.sql`

For the already-running Nefeon project, do not rerun every migration blindly. Run only a migration that has not already been applied. The migrations create the application, offer, onboarding and staff OTP/session tables and the private storage buckets used by the application.

Keep these buckets private: `nefeon-private-documents`, `nefeon-onboarding-documents` and `nefeon-offer-letters`. Do not add public read policies or use public storage URLs for resumes, identity documents, offer letters or signed copies.

## Deploy on Render

A `render.yaml` Blueprint is included for the Node web service, build/start commands, health check and environment-variable prompts.

1. Put the contents of this project folder in a Git repository you control. Do not commit `.env.local`, real credentials, applicant files or generated PDFs containing personal data.
2. In Render, create a new Blueprint from that repository or create a Node web service using the included settings.
3. Set the environment variables requested by `render.yaml`. Use the credentials for the Supabase project already containing your applications and migrations.
4. After Render gives the service its public URL, set `CAREERS_PUBLIC_URL` to that exact `https://…onrender.com` URL, then redeploy.
5. Open `/api/health` to confirm the service responds. Then test `/`, `/admin/login`, one test application, an offer email, a signed-offer upload and the final onboarding link using test data.
6. Check Resend logs and the application dashboard after each email test. Resend accepting a message does not itself guarantee inbox delivery.

Candidate links in offer and onboarding emails are bearer links. Do not post them publicly or forward them to anyone except the intended candidate. Test all links on the public HTTPS deployment before inviting real candidates.

## Workflow

1. A candidate submits the application form and PDF CV.
2. Authorized staff review the submission from `/admin`.
3. Staff prepare the supplied offer-letter PDF and email a private 14-day link through Resend.
4. The candidate downloads, signs and returns the PDF through the offer portal.
5. After the signed offer is recorded, staff can send a separate final-onboarding link.
6. The candidate submits onboarding details and required documents through the private portal. Staff review them before the application is marked onboarded.

## Before inviting real candidates

- Verify `nefeon.site` in Resend and use the sender address configured for that domain.
- Confirm the correct business name, address, GST details and internship terms in the offer PDF.
- Verify access restrictions for every private storage bucket.
- Use masked Aadhaar where accepted for the purpose; never request Aadhaar OTPs or biometric information. Keep access to identity documents restricted and follow the published retention/deletion process.
- Use test candidate information until all email, upload, download and status transitions have been confirmed on Render.
- A free Render service may sleep while idle; allow for a cold start before a candidate is expecting an immediate response.
