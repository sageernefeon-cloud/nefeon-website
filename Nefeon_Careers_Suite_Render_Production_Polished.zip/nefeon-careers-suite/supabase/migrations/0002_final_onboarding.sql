-- Final-stage onboarding: private, token-gated document collection after selection/offer.
-- Apply after 0001_initial_schema.sql in Supabase SQL Editor.

alter table public.applications drop constraint if exists applications_status_check;
alter table public.applications add constraint applications_status_check
  check (status in ('new','reviewing','shortlisted','interview','selected','offer_sent','accepted','rejected','withdrawn','onboarded'));

create table if not exists public.onboarding_requests (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  token_hash text not null unique,
  status text not null default 'pending' check (status in ('pending','completed','revoked','expired','email_failed')),
  expires_at timestamptz not null,
  legal_name text,
  current_address text,
  emergency_contact_name text,
  emergency_contact_phone text,
  emergency_contact_relationship text,
  privacy_notice_version text,
  consented_at timestamptz,
  completed_at timestamptz,
  created_by text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists onboarding_requests_application_idx on public.onboarding_requests(application_id, created_at desc);
create index if not exists onboarding_requests_status_idx on public.onboarding_requests(status, expires_at);
create unique index if not exists onboarding_one_pending_request_per_application_idx
  on public.onboarding_requests(application_id) where status = 'pending';

create table if not exists public.onboarding_documents (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.onboarding_requests(id) on delete cascade,
  document_type text not null check (document_type in ('aadhaar','passport_photo','education_proof','signed_offer','pan_card','other_document')),
  original_filename text not null,
  content_type text not null check (content_type in ('application/pdf','image/jpeg','image/png')),
  file_size bigint not null check (file_size > 0 and file_size <= 8388608),
  storage_path text not null unique,
  upload_confirmed_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists onboarding_documents_request_idx on public.onboarding_documents(request_id, document_type, created_at desc);

alter table public.onboarding_requests enable row level security;
alter table public.onboarding_documents enable row level security;
revoke all on table public.onboarding_requests from anon, authenticated;
revoke all on table public.onboarding_documents from anon, authenticated;
grant all on table public.onboarding_requests to service_role;
grant all on table public.onboarding_documents to service_role;

-- Separate private bucket for final-stage identity/education/offer documents and candidate photos.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('nefeon-onboarding-documents', 'nefeon-onboarding-documents', false, 8388608,
  array['application/pdf','image/jpeg','image/png'])
on conflict (id) do update set public = false, file_size_limit = 8388608,
  allowed_mime_types = array['application/pdf','image/jpeg','image/png'];
-- No anon/authenticated Storage policies are created. Uploads use short-lived signed upload URLs;
-- downloads are issued only by an authenticated staff route as short-lived signed URLs.
