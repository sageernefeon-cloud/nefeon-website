-- Nefeon Careers Suite: direct Resend OTP authentication.
-- Supabase remains the PostgreSQL database/private storage provider only;
-- the application does not call Supabase Auth to send or verify staff OTPs.

CREATE TABLE IF NOT EXISTS public.staff_login_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0 AND attempts <= 5),
  consumed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS staff_login_codes_email_created_idx
  ON public.staff_login_codes (email, created_at DESC);
CREATE INDEX IF NOT EXISTS staff_login_codes_expiry_idx
  ON public.staff_login_codes (expires_at);

CREATE TABLE IF NOT EXISTS public.staff_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_hash text NOT NULL UNIQUE,
  email text NOT NULL,
  role text NOT NULL CHECK (role IN ('owner', 'hr', 'manager')),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS staff_sessions_email_expiry_idx
  ON public.staff_sessions (email, expires_at DESC);

ALTER TABLE public.staff_login_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_sessions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.staff_login_codes FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.staff_sessions FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.staff_login_codes TO service_role;
GRANT ALL ON TABLE public.staff_sessions TO service_role;

-- Expired-code/session cleanup can be scheduled later. Authentication API
-- queries only current codes and active sessions; no client role can read these tables.


-- Atomically validate and consume an OTP while locking the row, so the same code
-- cannot be used to create multiple sessions through concurrent requests.
CREATE OR REPLACE FUNCTION public.consume_staff_login_code(
  p_code_id uuid,
  p_supplied_hash text
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  code_row public.staff_login_codes%ROWTYPE;
BEGIN
  SELECT * INTO code_row
  FROM public.staff_login_codes
  WHERE id = p_code_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN 'invalid';
  END IF;
  IF code_row.consumed_at IS NOT NULL OR code_row.expires_at <= now() THEN
    RETURN 'expired';
  END IF;
  IF code_row.attempts >= 5 THEN
    RETURN 'locked';
  END IF;
  IF code_row.code_hash <> p_supplied_hash THEN
    UPDATE public.staff_login_codes
    SET attempts = LEAST(attempts + 1, 5)
    WHERE id = p_code_id;
    IF code_row.attempts + 1 >= 5 THEN
      RETURN 'locked';
    END IF;
    RETURN 'wrong';
  END IF;

  UPDATE public.staff_login_codes
  SET consumed_at = now()
  WHERE id = p_code_id;
  RETURN 'ok';
END;
$$;

REVOKE ALL ON FUNCTION public.consume_staff_login_code(uuid, text)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.consume_staff_login_code(uuid, text)
  TO service_role;
