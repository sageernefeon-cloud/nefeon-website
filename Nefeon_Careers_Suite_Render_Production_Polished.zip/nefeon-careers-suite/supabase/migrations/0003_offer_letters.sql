-- Private offer-letter records. Candidate links are random, time-limited bearer tokens;
-- only the trusted server (service role) may read these rows or storage objects.
create table if not exists public.offer_letters (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  candidate_name text not null,
  candidate_email text not null,
  role text not null,
  offer_details jsonb not null,
  pdf_path text not null unique,
  token_hash text not null unique,
  status text not null default 'sent' check (status in ('sent','accepted','expired','revoked')),
  expires_at timestamptz not null,
  signed_pdf_path text unique,
  signed_uploaded_at timestamptz,
  accepted_at timestamptz,
  created_by text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists offer_letters_application_created_idx on public.offer_letters (application_id, created_at desc);
create index if not exists offer_letters_expiry_idx on public.offer_letters (status, expires_at);

alter table public.offer_letters enable row level security;
revoke all on table public.offer_letters from anon, authenticated;
grant all on table public.offer_letters to service_role;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('nefeon-offer-letters', 'nefeon-offer-letters', false, 8388608, array['application/pdf'])
on conflict (id) do update set public = false, file_size_limit = 8388608, allowed_mime_types = array['application/pdf'];
-- There are intentionally no anon/authenticated policies for this bucket.

-- Keep signed-copy submission, offer status, application status and audit log atomic.
create or replace function public.accept_offer_letter(p_offer_id uuid, p_signed_path text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  offer_row public.offer_letters%rowtype;
  current_application_status text;
  event_time timestamptz := now();
begin
  select * into offer_row
  from public.offer_letters
  where id = p_offer_id
  for update;

  if not found then
    raise exception 'Offer letter was not found';
  end if;
  if offer_row.status <> 'sent' or offer_row.expires_at <= event_time then
    raise exception 'Offer link is no longer active';
  end if;

  select status into current_application_status
  from public.applications
  where id = offer_row.application_id
  for update;
  if current_application_status not in ('selected', 'offer_sent') then
    raise exception 'This application is no longer active for offer acceptance';
  end if;

  update public.offer_letters
  set status = 'accepted', signed_pdf_path = p_signed_path,
      signed_uploaded_at = event_time, accepted_at = event_time, updated_at = event_time
  where id = offer_row.id;

  update public.applications
  set status = 'accepted', updated_at = event_time, updated_by = 'candidate:' || offer_row.candidate_email
  where id = offer_row.application_id;

  insert into public.audit_events(actor_email, action, application_id, details)
  values (offer_row.candidate_email, 'signed_offer_uploaded', offer_row.application_id,
    jsonb_build_object('offerLetterId', offer_row.id, 'uploadedAt', event_time));
end;
$$;
revoke all on function public.accept_offer_letter(uuid, text) from public, anon, authenticated;
grant execute on function public.accept_offer_letter(uuid, text) to service_role;
