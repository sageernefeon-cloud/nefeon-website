-- Nefeon Careers: direct website submission, protected applicant records and private resume storage.
-- Run once in Supabase SQL Editor on a new project. Never expose the service-role key to browser code.
create extension if not exists pgcrypto;

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  submission_id text not null unique,
  form_name text not null default 'Nefeon Internship Application',
  source text not null default 'website' check (source in ('website','manual')),
  applicant_name text not null,
  applicant_email text not null,
  phone text not null,
  city_state text not null,
  linkedin_url text,
  internship_role text not null,
  preferred_department text not null,
  work_arrangement text not null check (work_arrangement in ('Remote','Hybrid','On-site')),
  preferred_start_date date not null,
  internship_duration text not null,
  education_level text not null,
  institution text not null,
  degree text not null,
  graduation_year text not null,
  skills text not null,
  github_url text,
  motivation text not null,
  contribution text not null,
  project_highlight text,
  availability_hours text not null,
  additional_info text,
  resume_path text not null,
  resume_upload_ticket_id uuid not null unique,
  answers jsonb not null default '[]'::jsonb,
  accuracy_confirmed boolean not null default false,
  privacy_acknowledged boolean not null default false,
  privacy_notice_version text not null,
  consented_at timestamptz not null,
  submitted_at timestamptz not null default now(),
  status text not null default 'new' check (status in ('new','reviewing','shortlisted','interview','selected','offer_sent','accepted','rejected','withdrawn')),
  assigned_to text,
  notes text not null default '',
  applicant_confirmation_sent_at timestamptz,
  internal_notification_sent_at timestamptz,
  email_error text,
  offer_details jsonb,
  offer_sent_at timestamptz,
  updated_by text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists applications_submitted_at_idx on public.applications (submitted_at desc);
create index if not exists applications_status_idx on public.applications (status);
create index if not exists applications_email_idx on public.applications (lower(applicant_email));
create index if not exists applications_role_idx on public.applications (internship_role);

-- Short-lived upload tickets bind a private Storage upload to the applicant email and one application.
create table if not exists public.resume_upload_tickets (
  id uuid primary key,
  expected_email text not null,
  original_filename text not null,
  expected_file_size bigint not null check (expected_file_size > 0 and expected_file_size <= 10485760),
  storage_path text not null unique,
  expires_at timestamptz not null,
  consumed_at timestamptz,
  application_id uuid unique references public.applications(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists resume_upload_tickets_expires_at_idx on public.resume_upload_tickets (expires_at);

create table if not exists public.audit_events (
  id uuid primary key default gen_random_uuid(),
  actor_email text not null,
  action text not null,
  application_id uuid references public.applications(id) on delete set null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_events_created_at_idx on public.audit_events (created_at desc);

-- Browser users cannot directly query applicant rows or audit history. Trusted server routes use service-role credentials.
alter table public.applications enable row level security;
alter table public.audit_events enable row level security;
alter table public.resume_upload_tickets enable row level security;
revoke all on table public.applications from anon, authenticated;
revoke all on table public.audit_events from anon, authenticated;
revoke all on table public.resume_upload_tickets from anon, authenticated;
grant all on table public.applications to service_role;
grant all on table public.audit_events to service_role;
grant all on table public.resume_upload_tickets to service_role;

-- Private bucket. Only server routes may upload/download objects; no public URL is created.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('nefeon-private-documents', 'nefeon-private-documents', false, 10485760, array['application/pdf'])
on conflict (id) do update set public = false, file_size_limit = 10485760, allowed_mime_types = array['application/pdf'];

-- There are intentionally no anon/authenticated storage policies for this bucket.
