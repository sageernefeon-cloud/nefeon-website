import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { hashOnboardingToken, REQUIRED_ONBOARDING_DOCUMENTS } from '@/lib/onboarding';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const tokenPattern = /^[A-Za-z0-9_-]{40,50}$/;

function clean(value: unknown, max: number) { return String(value ?? '').trim().slice(0, max); }

export async function POST(request: NextRequest, context: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await context.params;
    if (!tokenPattern.test(token)) return NextResponse.json({ error: 'This onboarding link is invalid.' }, { status: 404 });
    const body = await request.json() as Record<string, unknown>;
    const legalName = clean(body.legalName, 160);
    const currentAddress = clean(body.currentAddress, 1000);
    const emergencyContactName = clean(body.emergencyContactName, 160);
    const emergencyContactPhone = clean(body.emergencyContactPhone, 30);
    const emergencyContactRelationship = clean(body.emergencyContactRelationship, 80);
    if (legalName.length < 2 || currentAddress.length < 8 || emergencyContactName.length < 2 || emergencyContactPhone.replace(/\D/g, '').length < 7 || emergencyContactRelationship.length < 2) {
      return NextResponse.json({ error: 'Please complete your legal name, current address and emergency contact details.' }, { status: 400 });
    }
    if (body.privacyConsent !== true) return NextResponse.json({ error: 'Please acknowledge the onboarding privacy notice before submitting.' }, { status: 400 });

    const supabase = getSupabaseAdmin();
    const { data: onboardingRequest, error: requestError } = await supabase.from('onboarding_requests').select('id,application_id,status,expires_at').eq('token_hash', hashOnboardingToken(token)).maybeSingle();
    if (requestError) throw requestError;
    if (!onboardingRequest || onboardingRequest.status !== 'pending') return NextResponse.json({ error: 'This onboarding request has already been submitted or is no longer active.' }, { status: 410 });
    if (new Date(onboardingRequest.expires_at).getTime() < Date.now()) {
      await supabase.from('onboarding_requests').update({ status: 'expired', updated_at: new Date().toISOString() }).eq('id', onboardingRequest.id);
      return NextResponse.json({ error: 'This onboarding link has expired. Contact Nefeon Careers for a new link.' }, { status: 410 });
    }
    const { data: docs, error: docsError } = await supabase.from('onboarding_documents').select('document_type,upload_confirmed_at,created_at')
      .eq('request_id', onboardingRequest.id).order('created_at', { ascending: false });
    if (docsError) throw docsError;
    const completedTypes = new Set<string>();
    for (const doc of docs ?? []) if (doc.upload_confirmed_at && !completedTypes.has(doc.document_type)) completedTypes.add(doc.document_type);
    const missing = REQUIRED_ONBOARDING_DOCUMENTS.filter((type) => !completedTypes.has(type));
    if (missing.length) return NextResponse.json({ error: `Upload and verify every required document before submitting. Missing: ${missing.join(', ')}.` }, { status: 400 });

    const completedAt = new Date().toISOString();
    const { data: updated, error: updateError } = await supabase.from('onboarding_requests').update({
      status: 'completed', legal_name: legalName, current_address: currentAddress,
      emergency_contact_name: emergencyContactName, emergency_contact_phone: emergencyContactPhone,
      emergency_contact_relationship: emergencyContactRelationship, privacy_notice_version: process.env.PRIVACY_NOTICE_VERSION || 'nefeon-onboarding-v1',
      consented_at: completedAt, completed_at: completedAt, updated_at: completedAt,
    }).eq('id', onboardingRequest.id).eq('status', 'pending').select('id').maybeSingle();
    if (updateError) throw updateError;
    if (!updated) return NextResponse.json({ error: 'This onboarding request has already been submitted. Refresh the page to see the final status.' }, { status: 409 });

    const { error: appError } = await supabase.from('applications').update({ status: 'onboarded', updated_at: completedAt, updated_by: 'candidate-onboarding' }).eq('id', onboardingRequest.application_id);
    if (appError) throw appError;
    await supabase.from('audit_events').insert({ actor_email: 'candidate-onboarding', action: 'onboarding_completed', application_id: onboardingRequest.application_id, details: { requestId: onboardingRequest.id, completedAt, documentTypes: [...completedTypes] } });
    return NextResponse.json({ completed: true, message: 'Your onboarding details and required documents have been submitted securely to Nefeon.' }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    console.error('[careers:onboarding-submit]', error);
    return NextResponse.json({ error: 'We could not finalize your onboarding. Your uploaded documents remain private; please retry or contact Nefeon Careers.' }, { status: 500 });
  }
}
