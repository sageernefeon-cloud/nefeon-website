import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { hashOnboardingToken, looksLikeFileType, MAX_ONBOARDING_FILE_BYTES, ONBOARDING_BUCKET, ONBOARDING_DOCUMENTS, type OnboardingDocumentType } from '@/lib/onboarding';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const tokenPattern = /^[A-Za-z0-9_-]{40,50}$/;

export async function POST(request: NextRequest, context: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await context.params;
    if (!tokenPattern.test(token)) return NextResponse.json({ error: 'This onboarding link is invalid.' }, { status: 404 });
    const body = await request.json() as { uploadId?: string };
    if (!body.uploadId || !/^[0-9a-f-]{36}$/i.test(body.uploadId)) return NextResponse.json({ error: 'A valid upload ID is required.' }, { status: 400 });
    const supabase = getSupabaseAdmin();
    const { data: onboardingRequest, error: requestError } = await supabase.from('onboarding_requests').select('id,status,expires_at').eq('token_hash', hashOnboardingToken(token)).maybeSingle();
    if (requestError) throw requestError;
    if (!onboardingRequest || onboardingRequest.status !== 'pending' || new Date(onboardingRequest.expires_at).getTime() < Date.now()) return NextResponse.json({ error: 'This onboarding link is no longer active.' }, { status: 410 });
    const { data: doc, error: docError } = await supabase.from('onboarding_documents').select('id,request_id,document_type,content_type,file_size,storage_path').eq('id', body.uploadId).eq('request_id', onboardingRequest.id).maybeSingle();
    if (docError) throw docError;
    if (!doc) return NextResponse.json({ error: 'The upload does not belong to this onboarding request.' }, { status: 404 });
    const { data: file, error: storageError } = await supabase.storage.from(ONBOARDING_BUCKET).download(doc.storage_path);
    if (storageError || !file) return NextResponse.json({ error: 'The upload could not be found in private storage. Please upload it again.' }, { status: 400 });
    if (file.size <= 0 || file.size > MAX_ONBOARDING_FILE_BYTES || file.size !== Number(doc.file_size)) return NextResponse.json({ error: 'The uploaded file size did not match. Please upload the file again.' }, { status: 400 });
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (!looksLikeFileType(bytes, doc.content_type)) return NextResponse.json({ error: 'The file content does not match its declared type. Please select the original PDF/JPG/PNG file.' }, { status: 400 });
    if (doc.document_type === 'passport_photo' && !['image/jpeg', 'image/png'].includes(doc.content_type)) return NextResponse.json({ error: 'Passport-size photos must be JPG or PNG.' }, { status: 400 });
    if (!Object.prototype.hasOwnProperty.call(ONBOARDING_DOCUMENTS, doc.document_type)) return NextResponse.json({ error: 'Unsupported document type.' }, { status: 400 });
    const uploadedAt = new Date().toISOString();
    const { error: updateError } = await supabase.from('onboarding_documents').update({ upload_confirmed_at: uploadedAt }).eq('id', doc.id);
    if (updateError) throw updateError;
    return NextResponse.json({ uploaded: true, uploadId: doc.id, uploadedAt }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    console.error('[careers:onboarding-confirm-upload]', error);
    return NextResponse.json({ error: 'The uploaded file could not be verified. Please try again.' }, { status: 500 });
  }
}
