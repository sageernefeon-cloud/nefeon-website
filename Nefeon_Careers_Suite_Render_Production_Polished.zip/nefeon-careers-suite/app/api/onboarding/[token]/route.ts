import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { hashOnboardingToken } from '@/lib/onboarding';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const tokenPattern = /^[A-Za-z0-9_-]{40,50}$/;

export async function GET(_request: NextRequest, context: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await context.params;
    if (!tokenPattern.test(token)) return NextResponse.json({ error: 'This onboarding link is invalid.' }, { status: 404 });
    const supabase = getSupabaseAdmin();
    const { data: onboardingRequest, error } = await supabase.from('onboarding_requests')
      .select('id,application_id,status,expires_at,completed_at,legal_name,current_address,emergency_contact_name,emergency_contact_phone,emergency_contact_relationship')
      .eq('token_hash', hashOnboardingToken(token)).maybeSingle();
    if (error) throw error;
    if (!onboardingRequest || onboardingRequest.status === 'revoked' || onboardingRequest.status === 'email_failed') {
      return NextResponse.json({ error: 'This onboarding link is invalid or no longer active. Contact Nefeon Careers for a new link.' }, { status: 404 });
    }
    if (onboardingRequest.status === 'expired') return NextResponse.json({ error: 'This onboarding link has expired. Contact Nefeon Careers for a new link.' }, { status: 410 });
    if (!['pending', 'completed'].includes(onboardingRequest.status)) return NextResponse.json({ error: 'This onboarding link is not active.' }, { status: 410 });
    if (onboardingRequest.status === 'pending' && new Date(onboardingRequest.expires_at).getTime() < Date.now()) {
      await supabase.from('onboarding_requests').update({ status: 'expired', updated_at: new Date().toISOString() }).eq('id', onboardingRequest.id);
      return NextResponse.json({ error: 'This onboarding link has expired. Contact Nefeon Careers for a new link.' }, { status: 410 });
    }
    const { data: application, error: applicationError } = await supabase.from('applications')
      .select('applicant_name,applicant_email,phone,internship_role').eq('id', onboardingRequest.application_id).single();
    if (applicationError) throw applicationError;
    const { data: allDocs, error: docsError } = await supabase.from('onboarding_documents')
      .select('id,document_type,original_filename,content_type,file_size,upload_confirmed_at,created_at')
      .eq('request_id', onboardingRequest.id).order('created_at', { ascending: false });
    if (docsError) throw docsError;
    const newestConfirmedByType = new Map<string, NonNullable<typeof allDocs>[number]>();
    for (const doc of allDocs ?? []) if (doc.upload_confirmed_at && !newestConfirmedByType.has(doc.document_type)) newestConfirmedByType.set(doc.document_type, doc);
    return NextResponse.json({
      candidate: { name: application.applicant_name, email: application.applicant_email, phone: application.phone, role: application.internship_role },
      request: { status: onboardingRequest.status, expiresAt: onboardingRequest.expires_at, completedAt: onboardingRequest.completed_at, legalName: onboardingRequest.legal_name, currentAddress: onboardingRequest.current_address, emergencyContactName: onboardingRequest.emergency_contact_name, emergencyContactPhone: onboardingRequest.emergency_contact_phone, emergencyContactRelationship: onboardingRequest.emergency_contact_relationship },
      documents: [...newestConfirmedByType.values()].map((doc) => ({ id: doc.id, documentType: doc.document_type, filename: doc.original_filename, contentType: doc.content_type, fileSize: doc.file_size, uploadedAt: doc.upload_confirmed_at })),
    }, { headers: { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' } });
  } catch (error) {
    console.error('[careers:onboarding-read]', error);
    return NextResponse.json({ error: 'Could not load this onboarding request. Please try again or contact Nefeon Careers.' }, { status: 500, headers: { 'Cache-Control': 'no-store' } });
  }
}
