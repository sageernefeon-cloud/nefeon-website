import { NextRequest, NextResponse } from 'next/server';
import { randomUUID } from 'node:crypto';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { hashOnboardingToken, MAX_ONBOARDING_FILE_BYTES, ONBOARDING_BUCKET, ONBOARDING_DOCUMENTS, isAllowedOnboardingMime, type OnboardingDocumentType } from '@/lib/onboarding';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const tokenPattern = /^[A-Za-z0-9_-]{40,50}$/;

export async function POST(request: NextRequest, context: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await context.params;
    if (!tokenPattern.test(token)) return NextResponse.json({ error: 'This onboarding link is invalid.' }, { status: 404 });
    const origin = request.headers.get('origin');
    if (origin && new URL(origin).host !== request.nextUrl.host) return NextResponse.json({ error: 'Request origin was not accepted.' }, { status: 403 });
    const body = await request.json() as { documentType?: string; fileName?: string; fileSize?: number; contentType?: string };
    const documentType = String(body.documentType ?? '') as OnboardingDocumentType;
    if (!Object.prototype.hasOwnProperty.call(ONBOARDING_DOCUMENTS, documentType)) return NextResponse.json({ error: 'Choose a supported document type.' }, { status: 400 });
    const fileName = String(body.fileName ?? '').trim().replace(/[\\/\u0000-\u001f]/g, '_').slice(0, 180);
    const fileSize = Number(body.fileSize);
    const contentType = String(body.contentType ?? '');
    if (!fileName || fileName.length > 180) return NextResponse.json({ error: 'Enter a valid filename.' }, { status: 400 });
    if (!Number.isFinite(fileSize) || fileSize <= 0 || fileSize > MAX_ONBOARDING_FILE_BYTES) return NextResponse.json({ error: 'Each file must be larger than 0 bytes and no more than 8 MB.' }, { status: 413 });
    if (!isAllowedOnboardingMime(documentType, contentType)) return NextResponse.json({ error: documentType === 'passport_photo' ? 'Passport-size photos must be JPG or PNG.' : 'Only PDF, JPG and PNG files are accepted.' }, { status: 400 });
    const extensionOk = contentType === 'application/pdf' ? /\.pdf$/i.test(fileName) : contentType === 'image/jpeg' ? /\.(jpe?g)$/i.test(fileName) : /\.png$/i.test(fileName);
    if (!extensionOk) return NextResponse.json({ error: 'The filename extension must match the selected file type.' }, { status: 400 });

    const supabase = getSupabaseAdmin();
    const { data: onboardingRequest, error: requestError } = await supabase.from('onboarding_requests').select('id,status,expires_at')
      .eq('token_hash', hashOnboardingToken(token)).maybeSingle();
    if (requestError) throw requestError;
    if (!onboardingRequest || onboardingRequest.status !== 'pending') return NextResponse.json({ error: 'This onboarding request is no longer active.' }, { status: 410 });
    if (new Date(onboardingRequest.expires_at).getTime() < Date.now()) {
      await supabase.from('onboarding_requests').update({ status: 'expired', updated_at: new Date().toISOString() }).eq('id', onboardingRequest.id);
      return NextResponse.json({ error: 'This onboarding link has expired. Contact Nefeon Careers for a new link.' }, { status: 410 });
    }

    const { data: existingUploads, error: countError } = await supabase.from('onboarding_documents').select('id').eq('request_id', onboardingRequest.id);
    if (countError) throw countError;
    if ((existingUploads ?? []).length >= 12) return NextResponse.json({ error: 'This onboarding request has reached its upload limit. Contact Nefeon Careers if you need to replace a file.' }, { status: 429 });

    const documentId = randomUUID();
    const extension = contentType === 'application/pdf' ? 'pdf' : contentType === 'image/jpeg' ? 'jpg' : 'png';
    const storagePath = `${onboardingRequest.id}/${documentId}.${extension}`;
    const { error: rowError } = await supabase.from('onboarding_documents').insert({
      id: documentId, request_id: onboardingRequest.id, document_type: documentType,
      original_filename: fileName, content_type: contentType, file_size: fileSize, storage_path: storagePath,
    });
    if (rowError) throw rowError;
    const { data, error } = await supabase.storage.from(ONBOARDING_BUCKET).createSignedUploadUrl(storagePath);
    if (error || !data?.token) {
      await supabase.from('onboarding_documents').delete().eq('id', documentId);
      throw new Error(`Could not create secure document upload: ${error?.message ?? 'Missing upload token'}`);
    }
    return NextResponse.json({ uploadId: documentId, path: storagePath, token: data.token }, { status: 201, headers: { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' } });
  } catch (error) {
    console.error('[careers:onboarding-upload-ticket]', error);
    return NextResponse.json({ error: 'Could not prepare the secure upload. Please try again.' }, { status: 500 });
  }
}
