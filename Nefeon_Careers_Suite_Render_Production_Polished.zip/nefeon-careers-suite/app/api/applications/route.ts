import { NextRequest, NextResponse } from 'next/server';
import { randomUUID, createHash } from 'node:crypto';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { sendApplicantConfirmation, sendTeamNotification } from '@/lib/email';
import { getCareersPublicUrl } from '@/lib/public-url';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const MAX_FILE_BYTES=10*1024*1024;
const BUCKET='nefeon-private-documents';
const roles=['AI / Machine Learning','Software Development','Frontend Development','Backend Development','UI/UX Design','Content Creation','Digital Marketing','Business Development','Market Research','Other'];
const departments=['AI / Product','Engineering','Design','Content','Marketing','Business / Research','Other'];
const arrangements=['Remote','Hybrid','On-site'];
const educationLevels=['Undergraduate','Postgraduate','Diploma','Recent graduate','Other'];
const durations=['1 month','2 months','3 months','4–6 months','Other'];
const weeklyHours=['Under 10 hours','10–20 hours','20–30 hours','30–40 hours'];
const windowMap=new Map<string,{count:number;start:number}>();
function overLimit(key:string){const now=Date.now(),span=15*60*1000,item=windowMap.get(key);if(!item||now-item.start>span){windowMap.set(key,{count:1,start:now});return false;}item.count++;return item.count>5;}
function textField(body:Record<string,unknown>,key:string,max=5000){const value=body[key];return typeof value==='string'?value.trim().slice(0,max):'';}
function validUrl(value:string){if(!value)return true;try{const url=new URL(value);return url.protocol==='https:'||url.protocol==='http:';}catch{return false;}}
function normalizeIndianMobile(raw: string) {
  const digits = raw.replace(/\D/g, '');
  const local = digits.length === 12 && digits.startsWith('91') ? digits.slice(2) : digits.length === 11 && digits.startsWith('0') ? digits.slice(1) : digits;
  return /^\d{10}$/.test(local) ? `+91 ${local}` : raw.trim();
}
function validEmail(value:string){return value.length<=320&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);}
function errorText(error:unknown){return error instanceof Error?error.message:'Unexpected server error.';}

export async function POST(request:NextRequest){
  try{
    const origin=request.headers.get('origin');
    if(origin&&new URL(origin).host!==request.nextUrl.host)return NextResponse.json({error:'Request origin was not accepted.'},{status:403});
    const ip=request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
    const ipKey=createHash('sha256').update(ip).digest('hex').slice(0,24);
    if(overLimit(ipKey))return NextResponse.json({error:'Too many applications were submitted from this connection. Please try again later.'},{status:429});
    const body=await request.json() as Record<string,unknown>;
    if(textField(body,'website',100))return NextResponse.json({error:'Application could not be accepted.'},{status:400});
    const startedAt=Number(body.formStartedAt);
    if(!Number.isFinite(startedAt)||startedAt<=0||Date.now()-startedAt<2500)return NextResponse.json({error:'Please review the application form and try again.'},{status:400});
    const v={
      fullName:textField(body,'fullName',120),email:textField(body,'email',320).toLowerCase(),phone:normalizeIndianMobile(textField(body,'phone',30)),cityState:textField(body,'cityState',120),linkedinUrl:textField(body,'linkedinUrl',500),
      role:textField(body,'role',100),department:textField(body,'department',100),workArrangement:textField(body,'workArrangement',30),preferredStartDate:textField(body,'preferredStartDate',20),duration:textField(body,'duration',50),durationOther:textField(body,'durationOther',80),
      educationLevel:textField(body,'educationLevel',80),institution:textField(body,'institution',180),degree:textField(body,'degree',180),graduationYear:textField(body,'graduationYear',20),skills:textField(body,'skills',4000),githubUrl:textField(body,'githubUrl',500),
      motivation:textField(body,'motivation',5000),contribution:textField(body,'contribution',5000),projectHighlight:textField(body,'projectHighlight',4000),availabilityHours:textField(body,'availabilityHours',50),additionalInfo:textField(body,'additionalInfo',4000),
    };
    const required:Array<[keyof typeof v,string]>=[['fullName','Full name'],['email','Email address'],['phone','Phone number'],['cityState','City and state'],['role','Internship role'],['department','Preferred department'],['workArrangement','Work arrangement'],['preferredStartDate','Preferred start date'],['duration','Internship duration'],['educationLevel','Education level'],['institution','College or university'],['degree','Degree'],['graduationYear','Graduation year'],['skills','Relevant skills'],['motivation','Motivation'],['contribution','Skills or contribution'],['availabilityHours','Weekly availability']];
    for(const [key,label] of required)if(!v[key])return NextResponse.json({error:`${label} is required.`},{status:400});
    if(!validEmail(v.email))return NextResponse.json({error:'Enter a valid email address.'},{status:400});
    if(!/^\+91 \d{10}$/.test(v.phone))return NextResponse.json({error:'Enter a valid 10-digit Indian mobile number.'},{status:400});
    if(!validUrl(v.linkedinUrl)||!validUrl(v.githubUrl))return NextResponse.json({error:'Portfolio links must be valid http or https URLs.'},{status:400});
    if(!roles.includes(v.role)||!departments.includes(v.department)||!arrangements.includes(v.workArrangement)||!educationLevels.includes(v.educationLevel)||!durations.includes(v.duration)||!weeklyHours.includes(v.availabilityHours))return NextResponse.json({error:'One or more selections are invalid.'},{status:400});
    if(v.duration==='Other'&&!v.durationOther)return NextResponse.json({error:'Please specify the internship duration.'},{status:400});
    if(!/^\d{4}-\d{2}-\d{2}$/.test(v.preferredStartDate)||Number.isNaN(Date.parse(`${v.preferredStartDate}T00:00:00Z`))||new Date(`${v.preferredStartDate}T00:00:00Z`).toISOString().slice(0,10)!==v.preferredStartDate)return NextResponse.json({error:'Choose a valid preferred start date.'},{status:400});
    if(v.preferredStartDate<new Date().toISOString().slice(0,10))return NextResponse.json({error:'Preferred start date cannot be in the past.'},{status:400});
    const yearNow=new Date().getUTCFullYear(); const allowedGradYears=new Set(Array.from({length:12},(_,i)=>String(yearNow-3+i)).concat('Other'));
    if(!allowedGradYears.has(v.graduationYear))return NextResponse.json({error:'Choose a valid graduation year.'},{status:400});
    if(body.accuracyConsent!==true||body.privacyConsent!==true)return NextResponse.json({error:'Both required confirmations must be accepted.'},{status:400});
    const ticketId=String(body.uploadTicketId??'');
    if(!/^[0-9a-f-]{36}$/i.test(ticketId))return NextResponse.json({error:'Your resume upload could not be verified. Please upload it again.'},{status:400});

    const supabase=getSupabaseAdmin();
    const {data:ticket,error:ticketError}=await supabase.from('resume_upload_tickets').select('id,expected_email,original_filename,expected_file_size,storage_path,expires_at,consumed_at').eq('id',ticketId).maybeSingle();
    if(ticketError)throw ticketError;
    if(!ticket||ticket.expected_email!==v.email)return NextResponse.json({error:'Your resume upload ticket does not match this email. Please upload your PDF again.'},{status:400});
    if(ticket.storage_path!==`resumes/${ticketId}/resume.pdf`)return NextResponse.json({error:'Resume upload path is invalid.'},{status:400});

    const {data:existing,error:existingError}=await supabase.from('applications').select('id,submission_id,applicant_confirmation_sent_at').eq('resume_upload_ticket_id',ticketId).maybeSingle();
    if(existingError)throw existingError;
    if(existing)return NextResponse.json({success:true,reference:existing.submission_id,emailSent:Boolean(existing.applicant_confirmation_sent_at)},{status:200});
    if(ticket.consumed_at||new Date(ticket.expires_at).getTime()<Date.now())return NextResponse.json({error:'Your resume upload ticket has expired. Please upload your PDF again.'},{status:400});
    const {data:file,error:fileError}=await supabase.storage.from(BUCKET).download(ticket.storage_path);
    if(fileError||!file)return NextResponse.json({error:'We could not find your uploaded resume. Please upload your PDF again.'},{status:400});
    if(file.size!==Number(ticket.expected_file_size)||file.size<=0||file.size>MAX_FILE_BYTES)return NextResponse.json({error:'The uploaded resume size could not be verified. Please upload it again.'},{status:400});
    const fileBytes=Buffer.from(await file.arrayBuffer());
    if(fileBytes.length<5||fileBytes.subarray(0,5).toString('ascii')!=='%PDF-')return NextResponse.json({error:'The uploaded file is not a valid PDF.'},{status:400});

    const id=randomUUID();
    const reference=`NEF-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${randomUUID().slice(0,6).toUpperCase()}`;
    const answers=[
      ['Full name',v.fullName],['Email address',v.email],['Phone number',v.phone],['Current city and state',v.cityState],['LinkedIn profile URL',v.linkedinUrl],
      ['Internship role',v.role],['Preferred department',v.department],['Work arrangement',v.workArrangement],['Preferred start date',v.preferredStartDate],['Internship duration',v.duration==='Other'?v.durationOther:v.duration],
      ['Education level',v.educationLevel],['College or university',v.institution],['Degree and specialization',v.degree],['Graduation year',v.graduationYear],['Relevant skills',v.skills],['GitHub or portfolio URL',v.githubUrl],
      ['Why do you want to join Nefeon?',v.motivation],['Skills or contribution',v.contribution],['Project or achievement',v.projectHighlight],['Availability per week',v.availabilityHours],['Additional information',v.additionalInfo]
    ].map(([label,value])=>({label,value}));
    const {error:insertError}=await supabase.from('applications').insert({
      id,submission_id:reference,resume_upload_ticket_id:ticketId,source:'website',form_name:'Nefeon Internship Application',applicant_name:v.fullName,applicant_email:v.email,phone:v.phone,city_state:v.cityState,
      linkedin_url:v.linkedinUrl||null,internship_role:v.role,preferred_department:v.department,work_arrangement:v.workArrangement,preferred_start_date:v.preferredStartDate,
      internship_duration:v.duration==='Other'?v.durationOther:v.duration,education_level:v.educationLevel,institution:v.institution,degree:v.degree,graduation_year:v.graduationYear,
      skills:v.skills,github_url:v.githubUrl||null,motivation:v.motivation,contribution:v.contribution,project_highlight:v.projectHighlight||null,availability_hours:v.availabilityHours,
      additional_info:v.additionalInfo||null,resume_path:ticket.storage_path,answers,accuracy_confirmed:true,privacy_acknowledged:true,
      privacy_notice_version:process.env.PRIVACY_NOTICE_VERSION||'2026-10-13-v1',consented_at:new Date().toISOString(),submitted_at:new Date().toISOString(),status:'new',notes:''
    });
    if(insertError)throw new Error(`Application could not be stored: ${insertError.message}`);
    const {error:consumeError}=await supabase.from('resume_upload_tickets').update({consumed_at:new Date().toISOString(),application_id:id}).eq('id',ticketId);
    if(consumeError)console.error('Could not mark resume upload ticket consumed',consumeError.message);

    let emailSent=false;let confirmationSentAt:string|null=null;let teamSentAt:string|null=null;const mailErrors:string[]=[];
    try{const result=await sendApplicantConfirmation(v.email,v.fullName,v.role,reference);if(result.error)throw new Error(result.error.message);emailSent=true;confirmationSentAt=new Date().toISOString();}catch(error){mailErrors.push(`Applicant confirmation: ${errorText(error)}`);}
    try{const teamEmail=process.env.CAREERS_NOTIFICATION_EMAIL;if(!teamEmail)throw new Error('CAREERS_NOTIFICATION_EMAIL is not configured.');const publicUrl=getCareersPublicUrl(request.nextUrl.origin);const result=await sendTeamNotification(teamEmail,v.fullName,v.email,v.role,reference,`${publicUrl}/admin`);if(result.error)throw new Error(result.error.message);teamSentAt=new Date().toISOString();}catch(error){mailErrors.push(`Team notification: ${errorText(error)}`);}
    await supabase.from('applications').update({applicant_confirmation_sent_at:confirmationSentAt,internal_notification_sent_at:teamSentAt,email_error:mailErrors.length?mailErrors.join(' | ').slice(0,2000):null}).eq('id',id);
    await supabase.from('audit_events').insert({actor_email:'system@nefeon.internal',action:'application_submitted',application_id:id,details:{source:'website',reference}});
    return NextResponse.json({success:true,reference,emailSent},{status:201});
  }catch(error){console.error('[careers:application-submit]',error);return NextResponse.json({error:'We could not finish saving your application. Please try again. If the issue continues, contact the careers team.'},{status:500});}
}
