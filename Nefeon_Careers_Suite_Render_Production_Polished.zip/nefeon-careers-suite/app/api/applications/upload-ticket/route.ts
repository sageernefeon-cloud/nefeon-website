import { NextRequest, NextResponse } from 'next/server';
import { randomUUID, createHash } from 'node:crypto';
import { getSupabaseAdmin } from '@/lib/supabase-server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const MAX_FILE_BYTES = 10 * 1024 * 1024;
const BUCKET = 'nefeon-private-documents';
const windowMap = new Map<string,{count:number;start:number}>();
function overLimit(key:string) {
  const now=Date.now(), span=15*60*1000, item=windowMap.get(key);
  if(!item||now-item.start>span){windowMap.set(key,{count:1,start:now});return false;}
  item.count++;return item.count>10;
}
export async function POST(request:NextRequest) {
  try {
    const origin=request.headers.get('origin');
    if(origin && new URL(origin).host!==request.nextUrl.host) return NextResponse.json({error:'Request origin was not accepted.'},{status:403});
    const ip=request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
    const key=createHash('sha256').update(ip).digest('hex').slice(0,24);
    if(overLimit(key)) return NextResponse.json({error:'Too many resume upload requests. Please wait and try again.'},{status:429});
    const body=await request.json() as {email?:string;fileName?:string;fileSize?:number;contentType?:string};
    const email=String(body.email??'').trim().toLowerCase();
    const fileName=String(body.fileName??'').trim().slice(0,180);
    const fileSize=Number(body.fileSize);
    const contentType=String(body.contentType??'');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>320) return NextResponse.json({error:'Enter a valid applicant email address before uploading the resume.'},{status:400});
    if(!fileName.toLowerCase().endsWith('.pdf')||contentType!=='application/pdf') return NextResponse.json({error:'Only PDF resumes are accepted.'},{status:400});
    if(!Number.isFinite(fileSize)||fileSize<=0||fileSize>MAX_FILE_BYTES) return NextResponse.json({error:'The PDF must be larger than 0 bytes and no more than 10 MB.'},{status:413});
    const supabase=getSupabaseAdmin();
    const id=randomUUID(); const storagePath=`resumes/${id}/resume.pdf`; const expiresAt=new Date(Date.now()+20*60*1000).toISOString();
    const {error:ticketError}=await supabase.from('resume_upload_tickets').insert({id,expected_email:email,original_filename:fileName,expected_file_size:fileSize,storage_path:storagePath,expires_at:expiresAt});
    if(ticketError) throw new Error(`Could not prepare private resume upload: ${ticketError.message}`);
    const {data,error}=await supabase.storage.from(BUCKET).createSignedUploadUrl(storagePath);
    if(error||!data?.token){await supabase.from('resume_upload_tickets').delete().eq('id',id);throw new Error(`Could not create secure upload URL: ${error?.message??'Missing upload token'}`);}
    return NextResponse.json({ticketId:id,path:storagePath,token:data.token,expiresAt},{status:201,headers:{'Cache-Control':'no-store'}});
  } catch(error) {
    console.error('[careers:upload-ticket]',error);
    return NextResponse.json({error:'Could not prepare the private resume upload. Please try again.'},{status:500});
  }
}
