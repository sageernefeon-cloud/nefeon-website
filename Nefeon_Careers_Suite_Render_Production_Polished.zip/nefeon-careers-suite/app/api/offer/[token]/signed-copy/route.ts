import { NextRequest, NextResponse } from 'next/server';
import { findOfferByToken, looksLikePdf, MAX_SIGNED_OFFER_BYTES, OFFER_BUCKET } from '@/lib/offers';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { getCareersPublicUrl } from '@/lib/public-url';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;

export async function POST(request: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  let savedPath: string | null = null;
  try {
    const { token } = await params;
    const { supabase, offer, error } = await findOfferByToken(token);
    if (error) throw error;
    if (!offer || offer.status === 'revoked') return NextResponse.json({ error: 'This offer link is invalid or revoked.' }, { status: 404 });
    if (offer.status === 'expired') return NextResponse.json({ error: 'This offer link has expired. Contact Nefeon Careers.' }, { status: 410 });
    if (offer.status === 'accepted' || offer.signed_pdf_path) return NextResponse.json({ error: 'A signed copy has already been received for this offer.' }, { status: 409 });

    const form = await request.formData();
    if (form.get('confirmSigned') !== 'yes') return NextResponse.json({ error: 'Please confirm that the uploaded PDF is your signed offer letter.' }, { status: 400 });
    const file = form.get('signedOffer');
    if (!(file instanceof File)) return NextResponse.json({ error: 'Choose the signed offer-letter PDF to upload.' }, { status: 400 });
    if (file.size <= 0 || file.size > MAX_SIGNED_OFFER_BYTES) return NextResponse.json({ error: 'The signed PDF must be larger than 0 bytes and no more than 8 MB.' }, { status: 400 });
    if (file.type !== 'application/pdf') return NextResponse.json({ error: 'Only a PDF of the signed offer letter is accepted.' }, { status: 400 });
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (!looksLikePdf(bytes)) return NextResponse.json({ error: 'The uploaded file does not appear to be a valid PDF.' }, { status: 400 });

    savedPath = `${offer.application_id}/${offer.id}/signed-offer-${Date.now()}.pdf`;
    const { error: uploadError } = await supabase.storage.from(OFFER_BUCKET).upload(savedPath, bytes, { contentType: 'application/pdf', upsert: false });
    if (uploadError) throw uploadError;
    const { error: acceptError } = await supabase.rpc('accept_offer_letter', { p_offer_id: offer.id, p_signed_path: savedPath });
    if (acceptError) throw acceptError;
    const notificationTo = process.env.CAREERS_NOTIFICATION_EMAIL?.trim();
    if (notificationTo) {
      try {
        const { sendSignedOfferReceivedEmail } = await import('@/lib/email');
        const publicUrl = getCareersPublicUrl(request.nextUrl.origin);
        const notification = await sendSignedOfferReceivedEmail(notificationTo, offer.candidate_name, offer.role, `${publicUrl}/admin`);
        if (notification.error) console.error('[careers:signed-offer-notification]', notification.error);
      } catch (notificationError) {
        console.error('[careers:signed-offer-notification]', notificationError);
      }
    }
    return NextResponse.json({ uploaded: true, message: 'Your signed offer letter has been submitted securely. The Nefeon Careers dashboard has been updated.' }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    if (savedPath) {
      try { await getSupabaseAdmin().storage.from(OFFER_BUCKET).remove([savedPath]); } catch { /* Preserve the original submission error if cleanup also fails. */ }
    }
    console.error('[careers:signed-offer-upload]', error);
    return NextResponse.json({ error: 'The signed offer letter could not be submitted. Please try again or contact Nefeon Careers.' }, { status: 500, headers: { 'Cache-Control': 'no-store' } });
  }
}
