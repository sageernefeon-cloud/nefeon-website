import { NextRequest, NextResponse } from 'next/server';
import { findOfferByToken } from '@/lib/offers';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function safeFilename(name: string) {
  return name.normalize('NFKD').replace(/[^a-zA-Z0-9 _-]/g, '').trim().replace(/\s+/g, '-') || 'candidate';
}

export async function GET(_request: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await params;
    const { supabase, offer, error } = await findOfferByToken(token);
    if (error) throw error;
    if (!offer || offer.status === 'revoked' || offer.status === 'expired') return NextResponse.json({ error: 'This offer link is invalid or expired. Contact Nefeon Careers.' }, { status: offer?.status === 'expired' ? 410 : 404, headers: { 'Cache-Control': 'no-store' } });
    const { data, error: downloadError } = await supabase.storage.from('nefeon-offer-letters').download(offer.pdf_path);
    if (downloadError || !data) throw downloadError ?? new Error('Offer PDF was not found in private storage.');
    const filename = `NEFEON-Internship-Offer-${safeFilename(offer.candidate_name)}.pdf`;
    return new NextResponse(data.stream(), { headers: {
      'Content-Type': 'application/pdf', 'Content-Length': String(data.size),
      'Content-Disposition': `attachment; filename="${filename}"`, 'Cache-Control': 'private, no-store, max-age=0',
      'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
    } });
  } catch (error) {
    console.error('[careers:offer-download]', error);
    return NextResponse.json({ error: 'The offer letter could not be downloaded. Contact Nefeon Careers.' }, { status: 500, headers: { 'Cache-Control': 'no-store' } });
  }
}
