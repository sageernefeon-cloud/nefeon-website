import { NextRequest, NextResponse } from 'next/server';
import { findOfferByToken } from '@/lib/offers';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(_request: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await params;
    const { offer, error } = await findOfferByToken(token);
    if (error) throw error;
    if (!offer || offer.status === 'revoked') return NextResponse.json({ error: 'This offer link is invalid or has been revoked. Contact Nefeon Careers for help.' }, { status: 404, headers: { 'Cache-Control': 'no-store' } });
    if (offer.status === 'expired') return NextResponse.json({ error: 'This offer link has expired. Contact Nefeon Careers to request a new link.' }, { status: 410, headers: { 'Cache-Control': 'no-store' } });
    return NextResponse.json({ candidateName: offer.candidate_name, role: offer.role, expiresAt: offer.expires_at, status: offer.status, signedUploaded: Boolean(offer.signed_pdf_path), issueDate: offer.offer_details?.issueDate ?? null, startDate: offer.offer_details?.startDate ?? null, endDate: offer.offer_details?.endDate ?? null }, { headers: { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' } });
  } catch (error) {
    console.error('[careers:offer-portal]', error);
    return NextResponse.json({ error: 'The offer link could not be checked. Please try again later.' }, { status: 500, headers: { 'Cache-Control': 'no-store' } });
  }
}
