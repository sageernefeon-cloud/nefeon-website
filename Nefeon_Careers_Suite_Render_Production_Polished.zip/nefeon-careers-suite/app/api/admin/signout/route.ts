import { createHash } from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
export const runtime = 'nodejs';
const SESSION_COOKIE = 'nefeon_staff_session';
export async function POST(request: NextRequest) {
  const token = request.cookies.get(SESSION_COOKIE)?.value;
  if (token) {
    const hash = createHash('sha256').update(token).digest('hex');
    const supabase = getSupabaseAdmin();
    await supabase.from('staff_sessions').update({ revoked_at: new Date().toISOString() }).eq('token_hash', hash).is('revoked_at', null);
  }
  const response = NextResponse.json({ signedOut: true });
  response.cookies.set(SESSION_COOKIE, '', { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', path: '/', maxAge: 0 });
  response.headers.set('Cache-Control', 'no-store');
  return response;
}
