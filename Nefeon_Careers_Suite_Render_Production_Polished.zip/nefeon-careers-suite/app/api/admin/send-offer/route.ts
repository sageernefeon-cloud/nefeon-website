import { randomBytes, randomUUID } from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { jsonErrorMessage, requireStaff } from '@/lib/staff-auth';
import { sendOfferLinkEmail } from '@/lib/email';
import { makeOfferLetterPdf, type OfferLetterFields } from '@/lib/offer-pdf';
import { hashOfferToken, OFFER_BUCKET, OFFER_LINK_LIFETIME_DAYS } from '@/lib/offers';
import { getCareersPublicUrl } from '@/lib/public-url';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;

type OfferInput = OfferLetterFields & { applicationId?: string };
const dateKeys: Array<keyof OfferLetterFields> = ['issueDate', 'startDate', 'endDate', 'acceptanceDeadline'];
const requiredKeys: Array<keyof OfferLetterFields> = ['issueDate', 'role', 'reportingTo', 'startDate', 'endDate', 'workingDays', 'startTime', 'endTime', 'hoursPerWeek', 'acceptanceDeadline'];
const datePattern = /^\d{4}-\d{2}-\d{2}$/;
function validDate(value: string) {
  return datePattern.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
}

export async function POST(request: NextRequest) {
  let createdOfferId: string | null = null;
  let uploadedPath: string | null = null;
  let emailAccepted = false;
  try {
    const staff = await requireStaff(request);
    const body = await request.json() as OfferInput;
    if (!body.applicationId || !/^[0-9a-f-]{36}$/i.test(body.applicationId)) return NextResponse.json({ error: 'A valid applicationId is required.' }, { status: 400 });
    for (const key of requiredKeys) if (!String(body[key] ?? '').trim()) return NextResponse.json({ error: `${key} is required.` }, { status: 400 });
    for (const key of dateKeys) if (!validDate(String(body[key]))) return NextResponse.json({ error: `${key} must be a valid calendar date.` }, { status: 400 });
    if (body.startDate > body.endDate) return NextResponse.json({ error: 'The end date must be on or after the start date.' }, { status: 400 });
    if (body.acceptanceDeadline > body.startDate) return NextResponse.json({ error: 'The acceptance deadline must be on or before the internship start date.' }, { status: 400 });
    for (const key of ['role', 'reportingTo', 'workingDays', 'startTime', 'endTime', 'hoursPerWeek'] as const) {
      if (String(body[key]).trim().length > 100) return NextResponse.json({ error: `${key} must be 100 characters or fewer.` }, { status: 400 });
    }

    const fields: OfferLetterFields = {
      issueDate: body.issueDate.trim(), role: body.role.trim(), reportingTo: body.reportingTo.trim(),
      startDate: body.startDate.trim(), endDate: body.endDate.trim(), workingDays: body.workingDays.trim(),
      startTime: body.startTime.trim(), endTime: body.endTime.trim(), hoursPerWeek: body.hoursPerWeek.trim(),
      acceptanceDeadline: body.acceptanceDeadline.trim(),
    };
    const supabase = getSupabaseAdmin();
    const { data: application, error: appError } = await supabase.from('applications')
      .select('id,applicant_name,applicant_email,status,internship_role').eq('id', body.applicationId).single();
    if (appError) throw appError;
    if (!application.applicant_email) return NextResponse.json({ error: 'This application has no usable applicant email address.' }, { status: 400 });
    if (!['selected', 'offer_sent'].includes(application.status)) return NextResponse.json({ error: 'Set the application status to Selected before sending an offer.' }, { status: 409 });
    const publicUrl = getCareersPublicUrl(request.nextUrl.origin);

    const pdfBytes = await makeOfferLetterPdf(fields, application.applicant_name ?? 'Candidate');
    const offerId = randomUUID();
    const accessToken = randomBytes(32).toString('base64url');
    const expiresAt = new Date(Date.now() + OFFER_LINK_LIFETIME_DAYS * 24 * 60 * 60 * 1000).toISOString();
    uploadedPath = `${application.id}/${offerId}/offer-letter.pdf`;
    const { error: uploadError } = await supabase.storage.from(OFFER_BUCKET).upload(uploadedPath, pdfBytes, { contentType: 'application/pdf', upsert: false });
    if (uploadError) throw uploadError;

    const { data: offerRecord, error: insertError } = await supabase.from('offer_letters').insert({
      id: offerId, application_id: application.id, candidate_name: application.applicant_name ?? 'Candidate',
      candidate_email: application.applicant_email, role: fields.role, offer_details: fields,
      pdf_path: uploadedPath, token_hash: hashOfferToken(accessToken), expires_at: expiresAt, status: 'sent', created_by: staff.email,
    }).select('id').single();
    if (insertError) throw insertError;
    createdOfferId = offerRecord.id;

    const offerUrl = `${publicUrl}/offer/${accessToken}`;
    const sent = await sendOfferLinkEmail(application.applicant_email, application.applicant_name ?? '', fields.role, offerUrl, expiresAt);
    if (sent.error) throw new Error(sent.error.message);
    emailAccepted = true;

    let followupWarning = false;
    // Once the new offer email is accepted by Resend, revoke older pending links.
    const { error: revokeError } = await supabase.from('offer_letters').update({ status: 'revoked', updated_at: new Date().toISOString() })
      .eq('application_id', application.id).eq('status', 'sent').neq('id', offerId);
    if (revokeError) { console.error('[careers:revoke-old-offer]', revokeError); followupWarning = true; }

    const now = new Date().toISOString();
    const { error: updateError } = await supabase.from('applications').update({
      status: 'offer_sent', offer_details: fields, offer_sent_at: now, updated_at: now, updated_by: staff.email,
    }).eq('id', application.id);
    if (updateError) { console.error('[careers:offer-application-status]', updateError); followupWarning = true; }
    const { error: auditError } = await supabase.from('audit_events').insert({ actor_email: staff.email, action: 'offer_letter_link_sent', application_id: application.id, details: { offerLetterId: offerId, role: fields.role, startDate: fields.startDate, expiresAt } });
    if (auditError) { console.error('[careers:offer-audit]', auditError); followupWarning = true; }
    return NextResponse.json({ sent: true, expiresAt, warning: followupWarning, message: followupWarning ? `Resend accepted the offer-link email for ${application.applicant_email}, but a dashboard update needs review before you resend.` : `Personalized offer-letter link sent to ${application.applicant_email}. It expires in ${OFFER_LINK_LIFETIME_DAYS} days.` }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    const supabase = getSupabaseAdmin();
    if (emailAccepted) {
      console.error('[careers:offer-after-email]', error);
      return NextResponse.json({ sent: true, warning: true, message: 'Resend accepted the offer-link email, but a follow-up update failed. Check the dashboard and Supabase before sending the offer again.' }, { headers: { 'Cache-Control': 'no-store' } });
    }
    if (createdOfferId) await supabase.from('offer_letters').update({ status: 'revoked', updated_at: new Date().toISOString() }).eq('id', createdOfferId);
    if (uploadedPath) await supabase.storage.from(OFFER_BUCKET).remove([uploadedPath]);
    const message = jsonErrorMessage(error);
    console.error('[careers:offer-link]', error);
    const status = message.includes('sign in') || message.includes('session') ? 401 : message.includes('authorized') ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
