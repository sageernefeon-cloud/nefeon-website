import { NextRequest, NextResponse } from 'next/server';
import { requireStaff, jsonErrorMessage } from '@/lib/staff-auth';
export const runtime = 'nodejs';
export async function GET(request: NextRequest) {
  try {
    const staff = await requireStaff(request);
    return NextResponse.json({ staff }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    const message = jsonErrorMessage(error);
    return NextResponse.json({ error: message }, { status: message.includes('authorized') ? 403 : 401, headers: { 'Cache-Control': 'no-store' } });
  }
}
