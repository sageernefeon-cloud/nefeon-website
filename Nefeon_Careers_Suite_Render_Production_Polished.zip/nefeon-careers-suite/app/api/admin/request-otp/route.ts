import { createHmac, randomInt } from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { isAllowedStaffEmail, jsonErrorMessage } from '@/lib/staff-auth';
import { sendStaffLoginOtpEmail } from '@/lib/email';

export const runtime = 'nodejs';

function otpHash(email: string, code: string) {
  const secret = process.env.STAFF_OTP_SECRET;
  if (!secret || secret.length < 32 || secret.startsWith('REPLACE_WITH') || secret.startsWith('replace_with')) throw new Error('STAFF_OTP_SECRET must be set to a unique random secret of at least 32 characters.');
  return createHmac('sha256', secret).update(`${email}:${code}`).digest('hex');
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as { email?: string };
    const email = String(body.email ?? '').trim().toLowerCase();
    if (!email || email.length > 320 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Enter a valid team email address.' }, { status: 400 });
    }
    if (!isAllowedStaffEmail(email)) {
      return NextResponse.json({ error: 'This email is not authorized to access the Nefeon careers dashboard.' }, { status: 403 });
    }

    const supabase = getSupabaseAdmin();
    const now = Date.now();
    const { data: latest, error: latestError } = await supabase
      .from('staff_login_codes').select('created_at').eq('email', email)
      .order('created_at', { ascending: false }).limit(1).maybeSingle();
    if (latestError) throw new Error('Staff OTP tables are missing or unavailable. Run supabase/migrations/0004_resend_staff_auth.sql in Supabase SQL Editor.');
    if (latest?.created_at && now - new Date(latest.created_at).getTime() < 60_000) {
      return NextResponse.json({ error: 'Please wait one minute before requesting another code.' }, { status: 429 });
    }
    const oneHourAgo = new Date(now - 60 * 60 * 1000).toISOString();
    const { count, error: countError } = await supabase.from('staff_login_codes')
      .select('id', { count: 'exact', head: true }).eq('email', email).gte('created_at', oneHourAgo);
    if (countError) throw new Error('Could not check sign-in rate limit. Please try again.');
    if ((count ?? 0) >= 5) return NextResponse.json({ error: 'Too many sign-in codes were requested for this email. Try again in an hour.' }, { status: 429 });

    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
    const codeHash = otpHash(email, code);
    const sentAt = new Date().toISOString();
    // Store the HMAC first; if Resend fails, invalidate the new row in the catch block below.
    const { data: insertedCode, error: insertError } = await supabase.from('staff_login_codes').insert({
      email, code_hash: codeHash, expires_at: new Date(now + 10 * 60 * 1000).toISOString(),
      attempts: 0, created_at: sentAt,
    }).select('id').single();
    if (insertError || !insertedCode) throw insertError ?? new Error('Could not prepare the sign-in code.');

    try {
      // Resend is the only email delivery provider for staff OTP.
      await sendStaffLoginOtpEmail(email, code);
    } catch (sendError) {
      await supabase.from('staff_login_codes').update({ consumed_at: new Date().toISOString() }).eq('id', insertedCode.id);
      throw sendError;
    }

    // Invalidate previous outstanding codes only after Resend accepted the new email.
    const { error: invalidateError } = await supabase.from('staff_login_codes')
      .update({ consumed_at: sentAt }).eq('email', email).is('consumed_at', null).neq('id', insertedCode.id);
    if (invalidateError) throw invalidateError;

    return NextResponse.json({ sent: true, message: 'A sign-in code has been sent through Resend. It expires in 10 minutes.' });
  } catch (error) {
    const message = jsonErrorMessage(error);
    const status = message.includes('STAFF_OTP_SECRET') || message.includes('configuration') || message.includes('missing or unavailable') ? 503 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
