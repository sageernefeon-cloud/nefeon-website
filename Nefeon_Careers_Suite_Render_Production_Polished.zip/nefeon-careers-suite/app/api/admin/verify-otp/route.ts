import { createHash, createHmac, randomBytes } from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { staffAllowlist } from '@/lib/staff-auth';
import { jsonErrorMessage } from '@/lib/staff-auth';

export const runtime = 'nodejs';
const SESSION_COOKIE = 'nefeon_staff_session';
const SESSION_TTL_SECONDS = 8 * 60 * 60;

function otpHash(email: string, code: string) {
  const secret = process.env.STAFF_OTP_SECRET;
  if (!secret || secret.length < 32 || secret.startsWith('REPLACE_WITH') || secret.startsWith('replace_with')) throw new Error('STAFF_OTP_SECRET must be set to a unique random secret of at least 32 characters.');
  return createHmac('sha256', secret).update(`${email}:${code}`).digest('hex');
}
function sha256(value: string) { return createHash('sha256').update(value).digest('hex'); }

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as { email?: string; otp?: string };
    const email = String(body.email ?? '').trim().toLowerCase();
    const otp = String(body.otp ?? '').trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !/^\d{6}$/.test(otp)) {
      return NextResponse.json({ error: 'Enter the staff email and the 6-digit code.' }, { status: 400 });
    }
    const role = staffAllowlist().get(email);
    if (!role) return NextResponse.json({ error: 'This email is not authorized to access the Nefeon careers dashboard.' }, { status: 403 });

    const supabase = getSupabaseAdmin();
    const now = new Date();
    const { data: codeRow, error: codeError } = await supabase.from('staff_login_codes')
      .select('id, code_hash, expires_at, attempts, consumed_at')
      .eq('email', email).is('consumed_at', null)
      .order('created_at', { ascending: false }).limit(1).maybeSingle();
    if (codeError) throw new Error('Staff OTP tables are missing or unavailable. Run supabase/migrations/0004_resend_staff_auth.sql in Supabase SQL Editor.');
    if (!codeRow || codeRow.consumed_at || new Date(codeRow.expires_at).getTime() <= now.getTime() || codeRow.attempts >= 5) {
      return NextResponse.json({ error: 'That code is invalid or expired. Request a new code and try again.' }, { status: 400 });
    }

    const suppliedHash = otpHash(email, otp);
    // Use a database row lock so parallel requests cannot consume the same OTP twice.
    const { data: consumeResult, error: consumeError } = await supabase.rpc('consume_staff_login_code', {
      p_code_id: codeRow.id,
      p_supplied_hash: suppliedHash,
    });
    if (consumeError) throw new Error('OTP verification function is missing. Run migration 0004_resend_staff_auth.sql.');
    if (consumeResult !== 'ok') {
      const message = consumeResult === 'wrong'
        ? 'That code is incorrect. Check the email and try again.'
        : consumeResult === 'locked'
          ? 'Too many incorrect attempts. Request a new code.'
          : 'That code is invalid or expired. Request a new code and try again.';
      return NextResponse.json({ error: message }, { status: 400 });
    }

    const sessionToken = randomBytes(32).toString('base64url');
    const expiresAt = new Date(now.getTime() + SESSION_TTL_SECONDS * 1000).toISOString();
    const { error: sessionError } = await supabase.from('staff_sessions').insert({
      email, role, token_hash: sha256(sessionToken), expires_at: expiresAt,
    });
    if (sessionError) throw sessionError;

    const response = NextResponse.json({ authenticated: true, staff: { email, role } });
    response.cookies.set(SESSION_COOKIE, sessionToken, {
      httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict',
      path: '/', maxAge: SESSION_TTL_SECONDS,
    });
    response.headers.set('Cache-Control', 'no-store');
    return response;
  } catch (error) {
    const message = jsonErrorMessage(error);
    const status = message.includes('configuration') || message.includes('missing or unavailable') ? 503 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
