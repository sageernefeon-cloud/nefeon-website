import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { jsonErrorMessage, requireStaff } from '@/lib/staff-auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request:NextRequest, context:{params:Promise<{id:string}>}) {
  try {
    await requireStaff(request);
    const {id}=await context.params;
    if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({error:'Invalid application ID.'},{status:400});
    const supabase=getSupabaseAdmin();
    const {data:app,error:appError}=await supabase.from('applications').select('applicant_name,resume_path,resume_upload_ticket_id').eq('id',id).single();
    if (appError) throw appError;
    if (!app.resume_path || !app.resume_upload_ticket_id || app.resume_path !== `resumes/${app.resume_upload_ticket_id}/resume.pdf`) return NextResponse.json({error:'No resume is attached to this application.'},{status:404});
    const {data:file,error:fileError}=await supabase.storage.from('nefeon-private-documents').download(app.resume_path);
    if (fileError || !file) return NextResponse.json({error:'The private resume could not be retrieved.'},{status:404});
    const safeName=(app.applicant_name||'applicant').replace(/[^a-z0-9-_ ]/gi,'').trim().replace(/\s+/g,'-').slice(0,70)||'applicant';
    return new Response(file.stream(),{status:200,headers:{'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="${safeName}-resume.pdf"`,'Cache-Control':'private, no-store, max-age=0','X-Content-Type-Options':'nosniff'} });
  } catch(error) {
    const message=jsonErrorMessage(error); const status=message.includes('sign in')||message.includes('session')?401:message.includes('authorized')?403:500;
    return NextResponse.json({error:message},{status});
  }
}
