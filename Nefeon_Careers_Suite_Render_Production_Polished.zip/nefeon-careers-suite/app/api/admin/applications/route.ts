import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { isAllowedStaffEmail, jsonErrorMessage, requireStaff } from '@/lib/staff-auth';

export const runtime = 'nodejs';
const allowedStatuses = ['new','reviewing','shortlisted','interview','selected','offer_sent','accepted','rejected','withdrawn','onboarded'];

export async function GET(request: NextRequest) {
  try {
    await requireStaff(request);
    const supabase = getSupabaseAdmin();
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    if (status && status !== 'all' && !allowedStatuses.includes(status)) return NextResponse.json({ error:'Invalid status filter.' }, { status:400 });
    const query = searchParams.get('q')?.trim().slice(0,200);
    let dbQuery = supabase.from('applications').select('id, submission_id, applicant_name, applicant_email, phone, city_state, linkedin_url, internship_role, preferred_department, work_arrangement, preferred_start_date, internship_duration, education_level, institution, degree, graduation_year, skills, github_url, motivation, contribution, project_highlight, availability_hours, additional_info, resume_path, status, submitted_at, updated_at, assigned_to, notes, answers, applicant_confirmation_sent_at, internal_notification_sent_at, email_error, offer_details, offer_sent_at').order('submitted_at',{ascending:false}).limit(250);
    if (status && status !== 'all') dbQuery = dbQuery.eq('status',status);
    const { data, error } = await dbQuery;
    if (error) throw error;
    const needle = query?.toLowerCase();
    const filtered = needle ? (data ?? []).filter(item => [item.applicant_name,item.applicant_email,item.internship_role,item.submission_id,item.city_state].some(value=>String(value??'').toLowerCase().includes(needle))) : data;
    return NextResponse.json({ applications:filtered ?? [] }, { headers:{'Cache-Control':'no-store'} });
  } catch (error) {
    const message = jsonErrorMessage(error);
    const status = message.includes('sign in') || message.includes('session') ? 401 : message.includes('authorized') ? 403 : 500;
    return NextResponse.json({error:message},{status});
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const staff = await requireStaff(request);
    const body = await request.json() as { applicationId?:string; status?:string; notes?:string; assignedTo?:string };
    if (!body.applicationId || !/^[0-9a-f-]{36}$/i.test(body.applicationId)) return NextResponse.json({error:'A valid applicationId is required.'},{status:400});
    if (body.status && !allowedStatuses.includes(body.status)) return NextResponse.json({error:'Invalid application status.'},{status:400});
    const supabase = getSupabaseAdmin();
    if (body.status === 'accepted') {
      const { data: signedOffer, error: signedOfferError } = await supabase.from('offer_letters')
        .select('id').eq('application_id', body.applicationId).eq('status', 'accepted')
        .not('signed_pdf_path', 'is', null).limit(1).maybeSingle();
      if (signedOfferError) throw signedOfferError;
      if (!signedOffer) return NextResponse.json({error:'Accepted status is set automatically only after the candidate uploads their signed offer letter.'},{status:409});
    }
    if (body.status === 'onboarded') {
      const { data: current, error: currentError } = await supabase.from('applications').select('status').eq('id', body.applicationId).maybeSingle();
      if (currentError) throw currentError;
      if (current?.status !== 'onboarded') return NextResponse.json({error:'The Onboarded status is set automatically only after the candidate submits all required onboarding documents.'},{status:409});
    }
    if (typeof body.notes === 'string' && body.notes.length > 10000) return NextResponse.json({error:'Notes are too long.'},{status:400});
    if (typeof body.assignedTo === 'string' && body.assignedTo.trim() && !isAllowedStaffEmail(body.assignedTo.trim().toLowerCase())) return NextResponse.json({error:'Assign this application only to an authorized Nefeon staff email.'},{status:400});
    if (body.status === 'rejected' || body.status === 'withdrawn') {
      const now = new Date().toISOString();
      const { error: offerRevokeError } = await supabase.from('offer_letters').update({ status: 'revoked', updated_at: now })
        .eq('application_id', body.applicationId).eq('status', 'sent');
      if (offerRevokeError) throw offerRevokeError;
      const { error: onboardingRevokeError } = await supabase.from('onboarding_requests').update({ status: 'revoked', updated_at: now })
        .eq('application_id', body.applicationId).eq('status', 'pending');
      if (onboardingRevokeError) throw onboardingRevokeError;
    }
    const updates:Record<string,unknown> = {updated_at:new Date().toISOString(),updated_by:staff.email};
    if (body.status) updates.status=body.status;
    if (typeof body.notes === 'string') updates.notes=body.notes.trim();
    if (typeof body.assignedTo === 'string') updates.assigned_to=body.assignedTo.trim().slice(0,320)||null;
    const {data,error} = await supabase.from('applications').update(updates).eq('id',body.applicationId).select('id,status,notes,assigned_to,updated_at').single();
    if (error) throw error;
    await supabase.from('audit_events').insert({actor_email:staff.email,action:'application_updated',application_id:body.applicationId,details:{status:body.status??null}});
    return NextResponse.json({application:data});
  } catch(error) {
    const message=jsonErrorMessage(error); const status=message.includes('sign in')||message.includes('session')?401:message.includes('authorized')?403:500;
    return NextResponse.json({error:message},{status});
  }
}
