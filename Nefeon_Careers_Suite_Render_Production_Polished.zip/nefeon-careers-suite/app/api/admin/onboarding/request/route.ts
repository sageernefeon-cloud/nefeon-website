import { NextRequest, NextResponse } from 'next/server';
import { randomBytes } from 'node:crypto';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { jsonErrorMessage, requireStaff } from '@/lib/staff-auth';
import { sendOnboardingRequestEmail } from '@/lib/email';
import { hashOnboardingToken } from '@/lib/onboarding';
import { getCareersPublicUrl } from '@/lib/public-url';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const staff = await requireStaff(request);
    const body = await request.json() as { applicationId?: string };
    if (!body.applicationId || !/^[0-9a-f-]{36}$/i.test(body.applicationId)) {
      return NextResponse.json({ error: 'A valid applicationId is required.' }, { status: 400 });
    }
    const supabase = getSupabaseAdmin();
    const { data: application, error: applicationError } = await supabase.from('applications')
      .select('id,applicant_name,applicant_email,internship_role,status').eq('id', body.applicationId).single();
    if (applicationError) throw applicationError;
    if (!application.applicant_email) return NextResponse.json({ error: 'This candidate has no usable email address.' }, { status: 400 });
    if (!['accepted', 'onboarded'].includes(application.status)) {
      return NextResponse.json({ error: 'Final onboarding can be requested only after the candidate has submitted the signed offer letter and the application status is Accepted.' }, { status: 409 });
    }
    const { data: signedOffer, error: signedOfferError } = await supabase.from('offer_letters')
      .select('id,status,signed_pdf_path,accepted_at')
      .eq('application_id', application.id).eq('status', 'accepted')
      .not('signed_pdf_path', 'is', null).order('accepted_at', { ascending: false }).limit(1).maybeSingle();
    if (signedOfferError) throw signedOfferError;
    if (!signedOffer) {
      return NextResponse.json({ error: 'The candidate must first download, sign and submit the offer letter. The final onboarding link becomes available after HR receives that signed PDF.' }, { status: 409 });
    }
    const publicUrl = getCareersPublicUrl(request.nextUrl.origin);
    const { data: latestRequest, error: latestError } = await supabase.from('onboarding_requests').select('status')
      .eq('application_id', application.id).order('created_at', { ascending: false }).limit(1).maybeSingle();
    if (latestError) throw latestError;
    if (latestRequest?.status === 'completed') return NextResponse.json({ error: 'This candidate has already completed onboarding. Use View status to review their documents.' }, { status: 409 });

    // Revoke any older active link before issuing a new one.
    const { error: revokeError } = await supabase.from('onboarding_requests').update({ status: 'revoked', updated_at: new Date().toISOString() })
      .eq('application_id', application.id).eq('status', 'pending');
    if (revokeError) throw revokeError;

    const token = randomBytes(32).toString('base64url');
    const expiresAt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString();
    const { data: onboardingRequest, error: insertError } = await supabase.from('onboarding_requests').insert({
      application_id: application.id,
      token_hash: hashOnboardingToken(token),
      status: 'pending',
      expires_at: expiresAt,
      created_by: staff.email,
    }).select('id').single();
    if (insertError) throw insertError;

    const onboardingUrl = `${publicUrl}/onboarding/${token}`;
    try {
      const result = await sendOnboardingRequestEmail(application.applicant_email, application.applicant_name ?? '', application.internship_role ?? '', onboardingUrl, expiresAt);
      if (result.error) throw new Error(result.error.message);
    } catch (emailError) {
      await supabase.from('onboarding_requests').update({ status: 'email_failed', expires_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', onboardingRequest.id);
      console.error('[careers:onboarding-email]', emailError);
      return NextResponse.json({ error: 'The onboarding record was prepared, but Resend could not deliver the email. Check EMAIL_FROM and Resend logs, then send a new request.' }, { status: 502 });
    }

    await supabase.from('audit_events').insert({ actor_email: staff.email, action: 'onboarding_request_sent', application_id: application.id, details: { expiresAt } });
    return NextResponse.json({ sent: true, expiresAt, message: `Secure onboarding link sent to ${application.applicant_email}. It expires in 14 days.` }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    const message = jsonErrorMessage(error);
    const status = message.includes('sign in') || message.includes('session') ? 401 : message.includes('authorized') ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
