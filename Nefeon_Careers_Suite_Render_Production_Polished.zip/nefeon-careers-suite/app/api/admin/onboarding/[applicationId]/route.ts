import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { jsonErrorMessage, requireStaff } from '@/lib/staff-auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest, context: { params: Promise<{ applicationId: string }> }) {
  try {
    await requireStaff(request);
    const { applicationId } = await context.params;
    if (!/^[0-9a-f-]{36}$/i.test(applicationId)) return NextResponse.json({ error: 'Invalid application ID.' }, { status: 400 });
    const supabase = getSupabaseAdmin();
    const { data: onboardingRequest, error } = await supabase.from('onboarding_requests')
      .select('id,status,expires_at,completed_at,legal_name,current_address,emergency_contact_name,emergency_contact_phone,emergency_contact_relationship,created_at')
      .eq('application_id', applicationId).order('created_at', { ascending: false }).limit(1).maybeSingle();
    if (error) throw error;
    if (!onboardingRequest) return NextResponse.json({ request: null, documents: [] }, { headers: { 'Cache-Control': 'no-store' } });
    const { data: allDocs, error: docsError } = await supabase.from('onboarding_documents')
      .select('id,document_type,original_filename,content_type,file_size,storage_path,upload_confirmed_at,created_at')
      .eq('request_id', onboardingRequest.id).order('created_at', { ascending: false });
    if (docsError) throw docsError;
    const newestConfirmedByType = new Map<string, NonNullable<typeof allDocs>[number]>();
    for (const doc of allDocs ?? []) {
      if (doc.upload_confirmed_at && !newestConfirmedByType.has(doc.document_type)) newestConfirmedByType.set(doc.document_type, doc);
    }
    const documents = await Promise.all([...newestConfirmedByType.values()].map(async (doc) => {
      const { data, error: signError } = await supabase.storage.from('nefeon-onboarding-documents').createSignedUrl(doc.storage_path, 60);
      return {
        id: doc.id,
        documentType: doc.document_type,
        filename: doc.original_filename,
        contentType: doc.content_type,
        fileSize: doc.file_size,
        uploadedAt: doc.upload_confirmed_at,
        downloadUrl: signError ? null : data?.signedUrl ?? null,
      };
    }));
    return NextResponse.json({ request: { ...onboardingRequest }, documents }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    const message = jsonErrorMessage(error);
    const status = message.includes('sign in') || message.includes('session') ? 401 : message.includes('authorized') ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
