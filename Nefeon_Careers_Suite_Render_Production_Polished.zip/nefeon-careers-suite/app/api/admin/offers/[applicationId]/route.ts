import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-server';
import { jsonErrorMessage, requireStaff } from '@/lib/staff-auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest, { params }: { params: Promise<{ applicationId: string }> }) {
  try {
    await requireStaff(request);
    const { applicationId } = await params;
    if (!/^[0-9a-f-]{36}$/i.test(applicationId)) return NextResponse.json({ error: 'A valid applicationId is required.' }, { status: 400 });
    const supabase = getSupabaseAdmin();
    const { data: offer, error } = await supabase.from('offer_letters').select('id,status,expires_at,signed_uploaded_at,accepted_at,created_at').eq('application_id', applicationId).order('created_at', { ascending: false }).limit(1).maybeSingle();
    if (error) throw error;
    if (!offer) return NextResponse.json({ offer: null }, { headers: { 'Cache-Control': 'no-store' } });
    let signedDownloadUrl: string | null = null;
    const { data: paths, error: signedError } = await supabase.from('offer_letters').select('signed_pdf_path').eq('id', offer.id).single();
    if (signedError) throw signedError;
    if (paths?.signed_pdf_path) {
      const { data: signedUrlData, error: urlError } = await supabase.storage.from('nefeon-offer-letters').createSignedUrl(paths.signed_pdf_path, 60, { download: 'signed-offer-letter.pdf' });
      if (urlError) throw urlError;
      signedDownloadUrl = signedUrlData.signedUrl;
    }
    return NextResponse.json({ offer, signedDownloadUrl }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    const message = jsonErrorMessage(error);
    const status = message.includes('sign in') || message.includes('session') ? 401 : message.includes('authorized') ? 403 : 500;
    return NextResponse.json({ error: message }, { status, headers: { 'Cache-Control': 'no-store' } });
  }
}
