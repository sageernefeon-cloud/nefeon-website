import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'NEFEON Careers — Offer Letter',
  robots: { index: false, follow: false, noarchive: true },
  referrer: 'no-referrer',
};

export default function OfferPortalLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return children;
}
