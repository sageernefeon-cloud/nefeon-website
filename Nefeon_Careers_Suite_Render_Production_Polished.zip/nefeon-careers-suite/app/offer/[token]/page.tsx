'use client';

import { ChangeEvent, FormEvent, useCallback, useEffect, useState } from 'react';
import { CheckCircle2, Download, FileCheck2, LockKeyhole, ShieldCheck, UploadCloud } from 'lucide-react';

type OfferPortalData = {
  candidateName: string;
  role: string;
  expiresAt: string;
  status: 'sent' | 'accepted' | 'expired' | 'revoked';
  signedUploaded: boolean;
  issueDate: string | null;
  startDate: string | null;
  endDate: string | null;
};
function formatDate(value: string) {
  try { return new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeZone: 'Asia/Kolkata' }).format(new Date(value)); }
  catch { return value; }
}

export default function OfferPortalPage({ params }: { params: Promise<{ token: string }> }) {
  const [token, setToken] = useState('');
  const [offer, setOffer] = useState<OfferPortalData | null>(null);
  const [signedFile, setSignedFile] = useState<File | null>(null);
  const [confirmSigned, setConfirmSigned] = useState(false);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const refresh = useCallback(async (resolvedToken: string) => {
    setLoading(true); setError('');
    try {
      const response = await fetch(`/api/offer/${resolvedToken}`, { cache: 'no-store', headers: { 'Cache-Control': 'no-store' } });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? 'This offer link could not be opened.');
      setOffer(data as OfferPortalData);
    } catch (e) { setError(e instanceof Error ? e.message : 'This offer link could not be opened.'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    let active = true;
    params.then(({ token: foundToken }) => { if (active) { setToken(foundToken); void refresh(foundToken); } });
    return () => { active = false; };
  }, [params, refresh]);

  function chooseFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0] ?? null;
    setError(''); setNotice('');
    if (!file) { setSignedFile(null); return; }
    if (file.type !== 'application/pdf' || !file.name.toLowerCase().endsWith('.pdf')) { setError('Please choose a PDF file of your signed offer letter.'); event.currentTarget.value = ''; return; }
    if (file.size <= 0 || file.size > 8 * 1024 * 1024) { setError('The signed PDF must be no more than 8 MB.'); event.currentTarget.value = ''; return; }
    setSignedFile(file);
  }

  async function submitSignedCopy(event: FormEvent) {
    event.preventDefault();
    if (!token || !signedFile || !confirmSigned) { setError('Choose the signed PDF and confirm that you have signed the offer.'); return; }
    setUploading(true); setError(''); setNotice('');
    try {
      const form = new FormData();
      form.set('signedOffer', signedFile);
      form.set('confirmSigned', 'yes');
      const response = await fetch(`/api/offer/${token}/signed-copy`, { method: 'POST', body: form, cache: 'no-store' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? 'The signed offer could not be submitted.');
      setNotice(result.message ?? 'Signed offer submitted securely.');
      setSignedFile(null); setConfirmSigned(false);
      await refresh(token);
    } catch (e) { setError(e instanceof Error ? e.message : 'The signed offer could not be submitted.'); }
    finally { setUploading(false); }
  }

  return <main className="onboarding-shell">
    <header className="onboarding-topbar"><a href="/" className="onboarding-brand"><span className="onboarding-mark">N</span><span>NEFEON<small>Careers · Offer letter</small></span></a><span className="onboarding-secure"><ShieldCheck size={15}/> Secure candidate portal</span></header>
    <section className="onboarding-card">
      <div className="onboarding-eyebrow"><span/> INTERNSHIP OFFER</div>
      <h1>{offer?.status === 'accepted' ? 'Signed offer received.' : 'Review your offer letter.'}</h1>
      {loading ? <p className="onboarding-muted">Checking your secure offer link…</p> : error && !offer ? <div className="onboarding-error" role="alert">{error}</div> : offer ? <>
        <p className="onboarding-intro">Hello {offer.candidateName}. Your internship offer for <strong>{offer.role}</strong> is ready to review.</p>
        <div className="onboarding-privacy"><LockKeyhole size={18}/><p>This link expires on <strong>{formatDate(offer.expiresAt)}</strong>. Download the PDF and review the terms. Sign the document using a PDF editor or print and sign it, then upload the signed copy below. If anything looks incorrect, contact Nefeon before signing.</p></div>
        <div className="onboarding-offer-summary">
          <div><span>Issue date</span><strong>{offer.issueDate ? formatDate(offer.issueDate) : '—'}</strong></div>
          <div><span>Internship start</span><strong>{offer.startDate ? formatDate(offer.startDate) : '—'}</strong></div>
          <div><span>Internship end</span><strong>{offer.endDate ? formatDate(offer.endDate) : '—'}</strong></div>
        </div>
        <a className="onboarding-submit onboarding-download-offer" href={`/api/offer/${token}/download`}><Download size={16}/> Download personalized offer letter (PDF)</a>
        {offer.status === 'accepted' || offer.signedUploaded ? <div className="onboarding-complete"><CheckCircle2 size={34}/><h2>Thank you. Your signed offer is submitted.</h2><p>Nefeon Careers has received your signed copy. The HR team can review it securely and follow up if anything else is needed.</p></div> : <form onSubmit={submitSignedCopy}>
          <div className="onboarding-section-heading"><span>01</span><div><h2>Return the signed offer</h2><p>Upload the PDF after you have added your signature and saved the file.</p></div></div>
          <label className="onboarding-signed-file"><UploadCloud size={22}/><strong>{signedFile ? signedFile.name : 'Choose signed offer PDF'}</strong><small>{signedFile ? `${(signedFile.size / 1024 / 1024).toFixed(2)} MB selected` : 'PDF only · Maximum 8 MB'}</small><input type="file" accept="application/pdf,.pdf" onChange={chooseFile}/></label>
          <label className="onboarding-consent"><input type="checkbox" checked={confirmSigned} onChange={(e) => setConfirmSigned(e.target.checked)}/><span>I confirm that I have reviewed and signed this offer letter, and that the uploaded PDF is my signed acceptance.</span></label>
          <button className="onboarding-submit" type="submit" disabled={uploading || !signedFile || !confirmSigned}><FileCheck2 size={16}/>{uploading ? 'Submitting signed offer…' : 'Submit signed offer letter'}</button>
        </form>}
      </> : null}
      {notice && <div className="onboarding-notice" role="status">{notice}</div>}
      {error && offer && <div className="onboarding-error" role="alert">{error}</div>}
      <p className="onboarding-footnote">Your offer PDF and signed copy are stored privately. Only authorized Nefeon staff can access them. This portal does not request Aadhaar or other identity documents.</p>
    </section>
    <footer className="onboarding-footer">NEFEON CAREERS · PRIVATE OFFER LETTER PORTAL</footer>
  </main>;
}
