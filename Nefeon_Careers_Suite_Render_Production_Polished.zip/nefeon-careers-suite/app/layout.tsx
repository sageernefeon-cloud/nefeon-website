import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Nefeon Careers | Internship Opportunities',
  description: 'View internship areas and apply to Nefeon Technology. Applications are reviewed by the team.',
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" data-scroll-behavior="smooth"><body>{children}</body></html>;
}
