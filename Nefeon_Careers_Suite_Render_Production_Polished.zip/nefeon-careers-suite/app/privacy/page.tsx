import Link from 'next/link';

export const metadata = {
  title: 'Applicant Privacy Notice | Nefeon Careers',
  description: 'How Nefeon handles internship applications and final-stage onboarding information.',
  robots: { index: true, follow: true },
};

export default function PrivacyPage() {
  const contact = process.env.CAREERS_NOTIFICATION_EMAIL || 'team.nefeon@gmail.com';
  const configuredName = process.env.COMPANY_LEGAL_NAME?.trim();
  const legalName = configuredName && configuredName.toLowerCase() !== 'nefeon'
    ? configuredName
    : 'Mohammed Sageer, proprietor of NEFEON';
  const retention = process.env.APPLICANT_DATA_RETENTION_MONTHS || '12';

  return <main className="admin-shell">
    <header className="admin-topbar">
      <Link href="/" className="admin-brand"><span className="brand-mark">N</span><span>NEFEON<small>Applicant privacy</small></span></Link>
      <Link href="/" className="subtle-btn">Back to careers</Link>
    </header>
    <article style={{ width: 'min(850px,calc(100% - 36px))', margin: '36px auto', padding: 'clamp(22px,5vw,42px)', border: '1px solid var(--line)', borderRadius: 12, background: '#fff', lineHeight: 1.8, color: '#536157', fontSize: 13 }}>
      <p className="admin-eyebrow">NEFEON CAREERS / PRIVACY</p>
      <h1 style={{ fontSize: 34, lineHeight: 1.2, color: '#253329', letterSpacing: '-.04em' }}>Applicant Privacy Notice</h1>
      <p>This notice explains how Nefeon handles information submitted through its internship application and final onboarding processes.</p>

      <h2 style={{ fontSize: 18, color: '#253329', marginTop: 28 }}>Who handles your information?</h2>
      <p>{legalName} operates this careers application under the NEFEON name. For questions about your information, contact <a href={`mailto:${contact}`}>{contact}</a>.</p>

      <h2 style={{ fontSize: 18, color: '#253329', marginTop: 28 }}>Information collected</h2>
      <p>The application form collects the details you provide, such as your name, email, Indian mobile number, city/state, professional links, internship preferences, education, skills, availability, responses, CV, consent records and application timestamps.</p>
      <p>Do not upload Aadhaar, bank details, passwords, OTPs or unrelated identity documents to the initial application form. After an offer is accepted, Nefeon may request the limited documents needed for final onboarding, such as accepted identity proof, a passport-size photograph and education or college proof. Where accepted for the intended purpose, a masked Aadhaar is preferred. PAN or additional records should be provided only when there is a relevant need.</p>

      <h2 style={{ fontSize: 18, color: '#253329', marginTop: 28 }}>How information is used</h2>
      <p>Information is used to review applications, contact candidates, arrange interviews, issue and manage internship offers, complete onboarding after selection, protect the service from abuse and maintain appropriate recruitment records.</p>

      <h2 style={{ fontSize: 18, color: '#253329', marginTop: 28 }}>Storage and service providers</h2>
      <p>Application and onboarding records are stored in Nefeon's configured Supabase database. CVs, offer PDFs and onboarding documents are held in separate private storage locations. Access is provided to authorized staff through protected routes or short-lived upload/download links. Resend is used to send application updates, team notifications, offer links and onboarding instructions. Identity documents are not attached to email notifications.</p>

      <h2 style={{ fontSize: 18, color: '#253329', marginTop: 28 }}>Retention and requests</h2>
      <p>Nefeon's current retention target is {retention} month(s), subject to applicable recordkeeping needs and any legal obligations. Records should be reviewed and deleted when no longer required; the retention schedule is not an assurance that every file is automatically deleted on a timer. You can email {contact} to ask about access, correction or deletion of your information, where applicable.</p>

      <h2 style={{ fontSize: 18, color: '#253329', marginTop: 28 }}>Keeping information safe</h2>
      <p>Access to applications and private documents is limited to authorized team members. Do not send identity documents by email or share Aadhaar OTPs or biometric information. You may choose not to apply, but required application details and a CV are needed to assess your application.</p>
      <p style={{ fontSize: 11, color: '#7a867d', borderTop: '1px solid var(--line)', paddingTop: 17, marginTop: 28 }}>Notice version: {process.env.PRIVACY_NOTICE_VERSION || '2026-10-20-v1'}.</p>
    </article>
  </main>;
}
