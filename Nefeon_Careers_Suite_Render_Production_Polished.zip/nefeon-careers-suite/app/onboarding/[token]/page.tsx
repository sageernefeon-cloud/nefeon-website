'use client';

import { ChangeEvent, FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { CheckCircle2, FileText, Image as ImageIcon, LockKeyhole, ShieldCheck, UploadCloud } from 'lucide-react';
import { getSupabaseBrowserClient } from '@/lib/supabase-browser';

type DocumentType = 'aadhaar' | 'passport_photo' | 'education_proof' | 'signed_offer' | 'pan_card' | 'other_document';
type UploadedDocument = { id: string; documentType: DocumentType; filename: string; contentType: string; fileSize: number; uploadedAt: string };
type OnboardingData = {
  candidate: { name: string | null; email: string | null; phone: string | null; role: string | null };
  request: { status: 'pending' | 'completed'; expiresAt: string; completedAt: string | null; legalName: string | null; currentAddress: string | null; emergencyContactName: string | null; emergencyContactPhone: string | null; emergencyContactRelationship: string | null };
  documents: UploadedDocument[];
};
type DocumentSpec = { id: DocumentType; label: string; hint: string; required: boolean; accept: string; imageOnly?: boolean };
const documentSpecs: DocumentSpec[] = [
  { id: 'aadhaar', label: 'Aadhaar card / ID document', hint: 'Upload one PDF containing the front and back, or a clear JPG/PNG image. Prefer masked Aadhaar where it is accepted for the purpose.', required: true, accept: '.pdf,.jpg,.jpeg,.png' },
  { id: 'passport_photo', label: 'Passport-size photo', hint: 'Use a recent, clear photo with your face visible. JPG or PNG only.', required: true, accept: '.jpg,.jpeg,.png', imageOnly: true },
  { id: 'education_proof', label: 'Education / college proof', hint: 'For example, college ID, enrollment certificate or relevant education proof.', required: true, accept: '.pdf,.jpg,.jpeg,.png' },
  { id: 'signed_offer', label: 'Signed offer letter (optional)', hint: 'You normally do not need to upload this again because the signed offer is submitted through the offer portal. Re-upload only if HR requests it.', required: false, accept: '.pdf' },
  { id: 'pan_card', label: 'PAN card (optional)', hint: 'Provide only if it is needed for your specific tax or payment process.', required: false, accept: '.pdf,.jpg,.jpeg,.png' },
  { id: 'other_document', label: 'Additional supporting document (optional)', hint: 'Only add another document requested by Nefeon HR.', required: false, accept: '.pdf,.jpg,.jpeg,.png' },
];
const MAX_BYTES = 8 * 1024 * 1024;
function normalizeIndianPhone(raw: string) {
  const digits = raw.replace(/\D/g, '');
  const local = (raw.trim().startsWith('+91') || (digits.startsWith('91') && digits.length > 10)) ? digits.slice(2, 12) : (digits.startsWith('0') && digits.length === 11) ? digits.slice(1) : digits.slice(0, 10);
  return local ? `+91 ${local}` : '';
}
function formatSize(size: number) { return size < 1024 * 1024 ? `${Math.max(1, Math.round(size / 1024))} KB` : `${(size / (1024 * 1024)).toFixed(1)} MB`; }
function formatDate(value: string) { try { return new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)); } catch { return value; } }

export default function CandidateOnboardingPage({ params }: { params: Promise<{ token: string }> }) {
  const [token, setToken] = useState('');
  const [data, setData] = useState<OnboardingData | null>(null);
  const [files, setFiles] = useState<Partial<Record<DocumentType, File>>>({});
  const [uploading, setUploading] = useState<DocumentType | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [completed, setCompleted] = useState(false);
  const [legalName, setLegalName] = useState('');
  const [currentAddress, setCurrentAddress] = useState('');
  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [emergencyContactRelationship, setEmergencyContactRelationship] = useState('');
  const [privacyConsent, setPrivacyConsent] = useState(false);

  const loadData = useCallback(async (resolvedToken: string) => {
    setLoading(true); setError('');
    try {
      const response = await fetch(`/api/onboarding/${resolvedToken}`, { cache: 'no-store', headers: { 'Cache-Control': 'no-store' } });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? 'This onboarding link could not be opened.');
      const packet = result as OnboardingData;
      setData(packet);
      setLegalName(packet.request.legalName || packet.candidate.name || '');
      setCurrentAddress(packet.request.currentAddress || '');
      setEmergencyContactName(packet.request.emergencyContactName || '');
      setEmergencyContactPhone(normalizeIndianPhone(packet.request.emergencyContactPhone || ''));
      setEmergencyContactRelationship(packet.request.emergencyContactRelationship || '');
      setCompleted(packet.request.status === 'completed');
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not load this onboarding request.'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    let alive = true;
    params.then(({ token: foundToken }) => { if (alive) { setToken(foundToken); void loadData(foundToken); } });
    return () => { alive = false; };
  }, [params, loadData]);

  const latestUploaded = useMemo(() => new Map((data?.documents ?? []).map((doc) => [doc.documentType, doc])), [data]);
  const requiredComplete = documentSpecs.filter((spec) => spec.required).every((spec) => latestUploaded.has(spec.id));

  function phoneInputValue(raw: string) {
    setEmergencyContactPhone(normalizeIndianPhone(raw));
  }

  function onFileChange(type: DocumentType, event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0];
    setError(''); setNotice('');
    if (!file) return;
    if (file.size <= 0 || file.size > MAX_BYTES) { setError('Each file must be larger than 0 bytes and no more than 8 MB.'); event.currentTarget.value = ''; return; }
    if (type === 'passport_photo' && !['image/jpeg', 'image/png'].includes(file.type)) { setError('Passport-size photos must be JPG or PNG.'); event.currentTarget.value = ''; return; }
    if (!['application/pdf', 'image/jpeg', 'image/png'].includes(file.type)) { setError('Only PDF, JPG and PNG files are accepted.'); event.currentTarget.value = ''; return; }
    setFiles((old) => ({ ...old, [type]: file }));
  }

  async function uploadFile(type: DocumentType) {
    const file = files[type];
    if (!file || !token) return;
    setUploading(type); setError(''); setNotice('');
    try {
      const ticketResponse = await fetch(`/api/onboarding/${token}/upload-ticket`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documentType: type, fileName: file.name, fileSize: file.size, contentType: file.type }),
      });
      const ticket = await ticketResponse.json();
      if (!ticketResponse.ok) throw new Error(ticket.error ?? 'Could not prepare secure upload.');
      const supabase = getSupabaseBrowserClient();
      const { error: uploadError } = await supabase.storage.from('nefeon-onboarding-documents').uploadToSignedUrl(ticket.path, ticket.token, file, { contentType: file.type, upsert: false });
      if (uploadError) throw new Error(uploadError.message);
      const confirmResponse = await fetch(`/api/onboarding/${token}/confirm-upload`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uploadId: ticket.uploadId }),
      });
      const confirmation = await confirmResponse.json();
      if (!confirmResponse.ok) throw new Error(confirmation.error ?? 'Could not verify the uploaded file.');
      setNotice(`${documentSpecs.find((spec) => spec.id === type)?.label ?? 'Document'} uploaded securely.`);
      setFiles((old) => ({ ...old, [type]: undefined }));
      await loadData(token);
    } catch (e) { setError(e instanceof Error ? e.message : 'The upload failed. Please try again.'); }
    finally { setUploading(null); }
  }

  async function submitOnboarding(event: FormEvent) {
    event.preventDefault();
    if (!token || !data) return;
    if (!requiredComplete || Object.values(files).some(Boolean)) { setError('Upload all required documents and finish any selected file uploads before submitting.'); return; }
    setSubmitting(true); setError(''); setNotice('');
    try {
      const response = await fetch(`/api/onboarding/${token}/submit`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ legalName, currentAddress, emergencyContactName, emergencyContactPhone, emergencyContactRelationship, privacyConsent }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? 'Could not submit onboarding.');
      setCompleted(true); setNotice(result.message ?? 'Onboarding submitted successfully.');
      await loadData(token);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not submit onboarding.'); }
    finally { setSubmitting(false); }
  }

  return <main className="onboarding-shell">
    <header className="onboarding-topbar"><a href="/" className="onboarding-brand"><span className="onboarding-mark">N</span><span>NEFEON<small>Careers · Final onboarding</small></span></a><span className="onboarding-secure"><ShieldCheck size={15}/> Private candidate portal</span></header>
    <section className="onboarding-card">
      <div className="onboarding-eyebrow"><span/> FINAL ONBOARDING STAGE</div>
      <h1>{completed ? 'Onboarding submitted.' : 'Complete your onboarding.'}</h1>
      {loading ? <p className="onboarding-muted">Checking your secure link…</p> : error && !data ? <div className="onboarding-error" role="alert">{error}</div> : data ? <>
        <p className="onboarding-intro">Hello {data.candidate.name || 'there'}{data.candidate.role ? ` — ${data.candidate.role}` : ''}. Complete the details below and upload the documents requested for final onboarding.</p>
        <div className="onboarding-privacy"><LockKeyhole size={18}/><p>Your files are uploaded to private storage. Only authorized Nefeon staff can access them. Do not email identity documents or share Aadhaar OTPs or biometrics. Where accepted for the intended purpose, a masked Aadhaar is preferred. <a href="/privacy" target="_blank" rel="noreferrer">Read the privacy notice</a>.</p></div>
        {completed ? <div className="onboarding-complete"><CheckCircle2 size={28}/><h2>Thank you, {data.request.legalName || data.candidate.name || 'candidate'}.</h2><p>Your onboarding details and required documents have been submitted securely to Nefeon.</p><small>Submitted {data.request.completedAt ? formatDate(data.request.completedAt) : 'successfully'}</small></div> : <form onSubmit={submitOnboarding}>
          <div className="onboarding-section-heading"><span>01</span><div><h2>Personal details</h2><p>Use the details shown on your official documents where applicable.</p></div></div>
          <div className="onboarding-fields">
            <label>Legal full name <input value={legalName} onChange={(e) => setLegalName(e.target.value)} required maxLength={160} autoComplete="name" /></label>
            <label className="onboarding-field-wide">Current full address <textarea value={currentAddress} onChange={(e) => setCurrentAddress(e.target.value)} required maxLength={1000} rows={3} autoComplete="street-address" placeholder="House / street, area, city, state and postal code" /></label>
            <label>Emergency contact name <input value={emergencyContactName} onChange={(e) => setEmergencyContactName(e.target.value)} required maxLength={160} /></label>
            <label>Emergency contact mobile <span className="phone-field"><span className="phone-prefix" aria-label="India country code"><span className="india-flag" aria-hidden="true">🇮🇳</span><span>+91</span></span><input value={emergencyContactPhone.replace(/^\+91\s*/, '').replace(/\D/g, '').slice(0,10)} onChange={(e) => phoneInputValue(e.target.value)} required maxLength={18} type="tel" inputMode="numeric" autoComplete="tel-national" aria-label="10-digit Indian mobile number" placeholder="98765 43210" /></span><small className="field-hint">Enter a 10-digit Indian mobile number.</small></label>
            <label className="onboarding-field-wide">Relationship to you <input value={emergencyContactRelationship} onChange={(e) => setEmergencyContactRelationship(e.target.value)} required maxLength={80} placeholder="For example, parent, guardian, spouse or friend" /></label>
          </div>
          <div className="onboarding-section-heading"><span>02</span><div><h2>Required documents</h2><p>Upload each required document. PDF, JPG and PNG are supported; each file can be up to 8 MB.</p></div></div>
          <div className="onboarding-documents">{documentSpecs.map((spec) => {
            const uploaded = latestUploaded.get(spec.id);
            const file = files[spec.id];
            return <article className="onboarding-document" key={spec.id}>
              <div className="onboarding-document-icon">{spec.id === 'passport_photo' ? <ImageIcon size={19}/> : <FileText size={19}/>}</div>
              <div className="onboarding-document-main"><div className="onboarding-document-title">{spec.label} {spec.required ? <span className="required-tag">REQUIRED</span> : <span className="optional-tag">OPTIONAL</span>}</div><p>{spec.hint}</p>
                {uploaded && <div className="onboarding-uploaded"><CheckCircle2 size={13}/> Uploaded: {uploaded.filename} · {formatSize(uploaded.fileSize)}</div>}
                <label className="onboarding-file-picker"><input type="file" accept={spec.accept} onChange={(event) => onFileChange(spec.id, event)} disabled={completed || uploading !== null}/><span>{file ? file.name : uploaded ? 'Choose a replacement file' : 'Choose file'}</span></label>
                {file && <button className="onboarding-upload-button" type="button" onClick={() => uploadFile(spec.id)} disabled={uploading !== null}>{uploading === spec.id ? 'Uploading and verifying…' : 'Upload securely'}</button>}
              </div>
            </article>;
          })}</div>
          <div className="onboarding-progress"><span>{documentSpecs.filter((spec) => spec.required && latestUploaded.has(spec.id)).length} of {documentSpecs.filter((spec) => spec.required).length} required documents uploaded</span><div><i style={{ width: `${documentSpecs.filter((spec) => spec.required && latestUploaded.has(spec.id)).length / documentSpecs.filter((spec) => spec.required).length * 100}%` }}/></div></div>
          <label className="onboarding-consent"><input type="checkbox" checked={privacyConsent} onChange={(e) => setPrivacyConsent(e.target.checked)} required/><span>I confirm that the information and documents I am submitting are accurate. I understand Nefeon will use them for final onboarding, restrict access to authorized staff, and retain or delete them according to its applicable record-retention process and privacy notice.</span></label>
          <button className="onboarding-submit" type="submit" disabled={submitting || uploading !== null || !requiredComplete || Object.values(files).some(Boolean) || !privacyConsent}>{submitting ? 'Submitting onboarding…' : 'Submit final onboarding details'} <UploadCloud size={16}/></button>
          <p className="onboarding-footnote">Your onboarding is submitted after all required files are uploaded and you select “Submit final onboarding details.” HR will review the documents after submission.</p>
        </form>}
        {notice && <div className="onboarding-notice" role="status">{notice}</div>}{error && <div className="onboarding-error" role="alert">{error}</div>}
      </> : null}
    </section>
    <footer className="onboarding-footer">NEFEON CAREERS · Documents are not public · <a href="/privacy">Privacy notice</a></footer>
  </main>;
}
