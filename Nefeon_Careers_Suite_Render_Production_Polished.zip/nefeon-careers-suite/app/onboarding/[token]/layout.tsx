import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Nefeon Careers — Final Onboarding',
  robots: { index: false, follow: false, noarchive: true },
  referrer: 'no-referrer',
};

export default function OnboardingLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return children;
}
