'use client';

import Link from 'next/link';
import { FormEvent, useMemo, useState, type ReactNode } from 'react';
import { getSupabaseBrowserClient } from '@/lib/supabase-browser';
import { ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, Check, CheckCircle2, Code2, Cpu, FileText, LockKeyhole, Mail, MapPin, Palette, ShieldCheck, UploadCloud, UserRound } from 'lucide-react';

type FormValues = {
  fullName: string; email: string; phone: string; cityState: string; linkedinUrl: string;
  role: string; department: string; workArrangement: string; preferredStartDate: string; duration: string; durationOther: string;
  educationLevel: string; institution: string; degree: string; graduationYear: string; skills: string; githubUrl: string;
  motivation: string; contribution: string; projectHighlight: string;
  availabilityHours: string; additionalInfo: string;
};
const initialValues: FormValues = {
  fullName:'', email:'', phone:'', cityState:'', linkedinUrl:'', role:'', department:'', workArrangement:'Remote', preferredStartDate:'', duration:'', durationOther:'',
  educationLevel:'', institution:'', degree:'', graduationYear:'', skills:'', githubUrl:'', motivation:'', contribution:'', projectHighlight:'', availabilityHours:'', additionalInfo:''
};
const steps = [
  { title: 'Personal Information', short: 'Tell us about you', note: 'Your contact details and profile.' },
  { title: 'Internship Details', short: 'Choose your path', note: 'The role and work arrangement.' },
  { title: 'Education & Skills', short: 'Your background', note: 'What you know and have built.' },
  { title: 'Resume & Motivation', short: 'Show your work', note: 'Your CV and what drives you.' },
  { title: 'Availability & Consent', short: 'Final review', note: 'Availability and confirmations.' },
];
const roleOptions = ['AI / Machine Learning','Software Development','Frontend Development','Backend Development','UI/UX Design','Content Creation','Digital Marketing','Business Development','Market Research','Other'];

function Field({ label, children, optional = false, hint }: { label:string; children:ReactNode; optional?:boolean; hint?:string }) {
  return <label className="career-field"><span className="career-label">{label}{optional && <span className="optional-label"> OPTIONAL</span>}</span>{children}{hint && <span className="field-hint">{hint}</span>}</label>;
}

export default function HomePage() {
  const [values, setValues] = useState<FormValues>(initialValues);
  const [step, setStep] = useState(0);
  const [resume, setResume] = useState<File|null>(null);
  const [accuracy, setAccuracy] = useState(false);
  const [privacy, setPrivacy] = useState(false);
  const [website, setWebsite] = useState('');
  const [startedAt] = useState(() => Date.now());
  const [errors, setErrors] = useState<Record<string,string>>({});
  const [busy, setBusy] = useState(false);
  const [submitted, setSubmitted] = useState<{ reference:string; emailSent:boolean }|null>(null);
  const [serverError, setServerError] = useState('');
  const progress = useMemo(() => (step + 1) * 20, [step]);
  function update<K extends keyof FormValues>(key:K, value:FormValues[K]) { setValues(prev => ({ ...prev, [key]:value })); setErrors(prev => ({ ...prev, [key]: '' })); }
  function phoneInputValue(raw: string) {
    const digits = raw.replace(/\D/g, '');
    const local = (raw.trim().startsWith('+91') || (digits.startsWith('91') && digits.length > 10)) ? digits.slice(2, 12) : (digits.startsWith('0') && digits.length === 11) ? digits.slice(1) : digits.slice(0, 10);
    update('phone', local ? `+91 ${local}` : '');
  }

  function validateStep(which:number) {
    const next:Record<string,string> = {};
    const requiredByStep:Record<number,(keyof FormValues)[]> = {
      0:['fullName','email','phone','cityState'],
      1:['role','department','workArrangement','preferredStartDate','duration'],
      2:['educationLevel','institution','degree','graduationYear','skills'],
      3:['motivation','contribution'],
      4:['availabilityHours'],
    };
    for (const key of requiredByStep[which] ?? []) if (!String(values[key] ?? '').trim()) next[key] = 'This field is required.';
    if (which === 0 && values.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) next.email = 'Enter a valid email address.';
    if (which === 0 && values.phone.replace(/\D/g, '').replace(/^91(?=\d{10}$)/, '').length !== 10) next.phone = 'Enter a valid 10-digit Indian mobile number.';
    if (which === 0 && values.linkedinUrl && !/^https?:\/\//i.test(values.linkedinUrl.trim())) next.linkedinUrl = 'Enter a complete URL beginning with https://.';
    if (which === 1 && values.duration === 'Other' && !values.durationOther.trim()) next.durationOther = 'Please specify the duration.';
    if (which === 2 && values.githubUrl && !/^https?:\/\//i.test(values.githubUrl.trim())) next.githubUrl = 'Enter a complete URL beginning with https://.';
    if (which === 3) {
      if (!resume) next.resume = 'Upload your resume as a PDF.';
      else if (resume.type !== 'application/pdf' || !resume.name.toLowerCase().endsWith('.pdf')) next.resume = 'Only PDF resumes are accepted.';
      else if (resume.size > 10 * 1024 * 1024) next.resume = 'The PDF must be 10 MB or smaller.';
    }
    if (which === 4) {
      if (!accuracy) next.accuracy = 'Please confirm the information is accurate.';
      if (!privacy) next.privacy = 'Please acknowledge the Applicant Privacy Notice.';
    }
    setErrors(prev => ({...prev,...next}));
    return Object.keys(next).length === 0;
  }
  function nextStep() { setServerError(''); if (validateStep(step)) setStep(s => Math.min(4,s+1)); }
  function previousStep() { setServerError(''); setStep(s => Math.max(0,s-1)); }
  async function submitApplication(event:FormEvent<HTMLFormElement>) {
    event.preventDefault(); setServerError('');
    // Validate every section again on the client; the server repeats all security-critical validation.
    for (let i=0;i<5;i++) if (!validateStep(i)) { setStep(i); return; }
    if (!resume) return;
    setBusy(true);
    try {
      const ticketResponse = await fetch('/api/applications/upload-ticket', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email:values.email,fileName:resume.name,fileSize:resume.size,contentType:resume.type}) });
      const ticket = await ticketResponse.json();
      if (!ticketResponse.ok) throw new Error(ticket.error || 'Could not prepare the private resume upload.');
      const supabase = getSupabaseBrowserClient();
      const { error: uploadError } = await supabase.storage.from('nefeon-private-documents').uploadToSignedUrl(ticket.path, ticket.token, resume, { contentType:'application/pdf' });
      if (uploadError) throw new Error(`Resume upload failed: ${uploadError.message}`);
      const response = await fetch('/api/applications', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...values,uploadTicketId:ticket.ticketId,accuracyConsent:accuracy,privacyConsent:privacy,website,formStartedAt:startedAt}) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'We could not submit your application. Please try again.');
      setSubmitted({ reference: result.reference, emailSent: Boolean(result.emailSent) });
      window.scrollTo({top:0,behavior:'smooth'});
    } catch (error) { setServerError(error instanceof Error ? error.message : 'Submission failed. Please try again.'); }
    finally { setBusy(false); }
  }

  const roles = [
    { title:'AI & Machine Learning', icon:Cpu, description:'Support research, experimentation and practical engineering tasks.' },
    { title:'Software Engineering', icon:Code2, description:'Contribute to web applications, APIs and everyday development work.' },
    { title:'Design & Content', icon:Palette, description:'Help prepare clear visual assets, content and user experiences.' },
  ];

  return <main className="site-shell">
    <header className="site-header page-width">
      <Link href="/" className="brand" aria-label="Nefeon careers home"><span className="brand-mark">N</span><span>NEFEON</span></Link>
      <div className="header-right"><span className="header-caption">CAREERS AT NEFEON</span><span className="header-subcaption">Remote internships · Bengaluru, India</span></div>
    </header>

    <section className="hero page-width">
      <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot" /> INTERNSHIP OPPORTUNITIES</div><h1>Internships at<br/><span className="gradient-text">Nefeon.</span></h1><p className="hero-intro">Join our small technology team, contribute to practical work, and learn alongside people who will review your progress and help you improve.</p><p className="hero-small">Remote · Currently unpaid · Applications reviewed by our team</p><a className="text-link" href="#open-roles">View internship areas <ArrowDownRight size={16}/></a></div>
      <div className="hero-side-note"><ShieldCheck size={17}/><span>REMOTE<br/>INTERNSHIPS</span></div>
    </section>

    <section className="opportunities page-width" id="open-roles"><div className="section-heading"><div><p className="section-kicker">INTERNSHIP AREAS</p><h2>Choose an area that fits your skills</h2></div><span className="section-count">01 — 03</span></div><div className="role-grid">{roles.map((role,i)=>{const Icon=role.icon;return <article className="role-card" key={role.title}><div className="role-card-top"><span className="role-icon"><Icon size={19}/></span><span className="role-index">0{i+1}</span></div><h3>{role.title}</h3><p>{role.description}</p><a href="#apply" aria-label={`Apply for ${role.title}`} className="card-arrow"><ArrowUpRight size={18}/></a></article>;})}</div></section>

    <section className="application-section page-width" id="apply">
      {!submitted ? <>
        <div className="application-intro"><p className="section-kicker">APPLY TO NEFEON</p><h2>Internship application</h2><p>Complete the form below and attach your CV as a PDF. We will email you a reference number after your application is saved.</p><div className="application-meta"><span className="status-live"/> Five short steps <span className="meta-divider">·</span> CV required <span className="meta-divider">·</span> Secure submission</div></div>
        <div className="form-layout">
          <div className="form-frame"><div className="form-frame-top"><span className="form-live"><span/> NEFEON APPLICATION PORTAL</span><span className="form-secure"><LockKeyhole size={11} style={{verticalAlign:'middle',marginRight:5}}/> PRIVATE SUBMISSION</span></div>
            <form className="careers-form" onSubmit={submitApplication} noValidate>
              <div className="progress-row"><span>{step+1} / 5</span><div className="progress-track"><div className="progress-fill" style={{width:`${progress}%`}}/></div><span>{progress}%</span></div>
              <div className="form-step-heading"><span className="step-orb">{step+1}</span><div><h3>{steps[step].title}</h3><p>{steps[step].note}</p></div></div>
              {step===0 && <div className="fields-stack">
                <Field label="Full name"><span className="icon-field"><UserRound size={15}/><input autoComplete="name" value={values.fullName} onChange={e=>update('fullName',e.target.value)} placeholder="Enter your full name" maxLength={120}/></span>{errors.fullName&&<small className="field-error">{errors.fullName}</small>}</Field>
                <Field label="Email address"><span className="icon-field"><Mail size={15}/><input type="email" autoComplete="email" value={values.email} onChange={e=>update('email',e.target.value)} placeholder="you@example.com" maxLength={320}/></span>{errors.email&&<small className="field-error">{errors.email}</small>}</Field>
                <Field label="Mobile number"><span className="phone-field"><span className="phone-prefix" aria-label="India country code"><span className="india-flag" aria-hidden="true">🇮🇳</span><span>+91</span></span><input type="tel" inputMode="numeric" autoComplete="tel-national" aria-label="10-digit Indian mobile number" value={values.phone.replace(/^\+91\s*/, '').replace(/\D/g, '').slice(0,10)} onChange={e=>phoneInputValue(e.target.value)} placeholder="98765 43210" maxLength={18}/></span>{errors.phone&&<small className="field-error">{errors.phone}</small>}<span className="field-hint">India (+91). Enter your 10-digit mobile number.</span></Field>
                <Field label="Current city and state"><span className="icon-field"><MapPin size={15}/><input autoComplete="address-level2" value={values.cityState} onChange={e=>update('cityState',e.target.value)} placeholder="e.g. Bengaluru, Karnataka" maxLength={120}/></span>{errors.cityState&&<small className="field-error">{errors.cityState}</small>}</Field>
                <Field label="LinkedIn profile URL" optional><span className="icon-field"><ArrowUpRight size={15}/><input type="url" value={values.linkedinUrl} onChange={e=>update('linkedinUrl',e.target.value)} placeholder="https://linkedin.com/in/yourname" maxLength={500}/></span>{errors.linkedinUrl&&<small className="field-error">{errors.linkedinUrl}</small>}</Field>
              </div>}
              {step===1 && <div className="fields-stack">
                <Field label="Internship role"><select value={values.role} onChange={e=>update('role',e.target.value)}><option value="">Choose a role</option>{roleOptions.map(x=><option key={x}>{x}</option>)}</select>{errors.role&&<small className="field-error">{errors.role}</small>}</Field>
                <Field label="Preferred department"><select value={values.department} onChange={e=>update('department',e.target.value)}><option value="">Choose a department</option><option>AI / Product</option><option>Engineering</option><option>Design</option><option>Content</option><option>Marketing</option><option>Business / Research</option><option>Other</option></select>{errors.department&&<small className="field-error">{errors.department}</small>}</Field>
                <Field label="Work arrangement"><div className="choice-grid">{['Remote','Hybrid','On-site'].map(x=><button type="button" key={x} className={`choice-pill ${values.workArrangement===x?'selected':''}`} onClick={()=>update('workArrangement',x)}>{values.workArrangement===x&&<Check size={14}/>} {x}</button>)}</div>{errors.workArrangement&&<small className="field-error">{errors.workArrangement}</small>}</Field>
                <Field label="Preferred start date"><input type="date" value={values.preferredStartDate} min={new Date().toISOString().slice(0,10)} onChange={e=>update('preferredStartDate',e.target.value)}/>{errors.preferredStartDate&&<small className="field-error">{errors.preferredStartDate}</small>}</Field>
                <Field label="Internship duration"><select value={values.duration} onChange={e=>update('duration',e.target.value)}><option value="">Choose duration</option><option>1 month</option><option>2 months</option><option>3 months</option><option>4–6 months</option><option>Other</option></select>{errors.duration&&<small className="field-error">{errors.duration}</small>}</Field>
                {values.duration==='Other'&&<Field label="Please specify duration"><input value={values.durationOther} onChange={e=>update('durationOther',e.target.value)} maxLength={80} placeholder="e.g. 8 weeks"/>{errors.durationOther&&<small className="field-error">{errors.durationOther}</small>}</Field>}
              </div>}
              {step===2 && <div className="fields-stack">
                <Field label="Current education level"><select value={values.educationLevel} onChange={e=>update('educationLevel',e.target.value)}><option value="">Choose education level</option><option>Undergraduate</option><option>Postgraduate</option><option>Diploma</option><option>Recent graduate</option><option>Other</option></select>{errors.educationLevel&&<small className="field-error">{errors.educationLevel}</small>}</Field>
                <Field label="College or university"><input value={values.institution} onChange={e=>update('institution',e.target.value)} placeholder="Your college or institution" maxLength={180}/>{errors.institution&&<small className="field-error">{errors.institution}</small>}</Field>
                <Field label="Degree and specialization"><input value={values.degree} onChange={e=>update('degree',e.target.value)} placeholder="e.g. B.E. Computer Science" maxLength={180}/>{errors.degree&&<small className="field-error">{errors.degree}</small>}</Field>
                <Field label="Expected or completed graduation year"><select value={values.graduationYear} onChange={e=>update('graduationYear',e.target.value)}><option value="">Choose year</option>{Array.from({length:12},(_,i)=>new Date().getFullYear()-3+i).map(y=><option key={y}>{y}</option>)}<option>Other</option></select>{errors.graduationYear&&<small className="field-error">{errors.graduationYear}</small>}</Field>
                <Field label="Relevant skills"><textarea rows={3} value={values.skills} onChange={e=>update('skills',e.target.value)} placeholder="Languages, tools, technologies, creative skills…" maxLength={4000}/>{errors.skills&&<small className="field-error">{errors.skills}</small>}</Field>
                <Field label="GitHub or portfolio URL" optional><input type="url" value={values.githubUrl} onChange={e=>update('githubUrl',e.target.value)} placeholder="https://github.com/yourname" maxLength={500}/>{errors.githubUrl&&<small className="field-error">{errors.githubUrl}</small>}</Field>
              </div>}
              {step===3 && <div className="fields-stack">
                <div className="career-field"><span className="career-label">Resume / CV (PDF only)</span><span className="field-hint">PDF · Maximum 10 MB · Stored privately for Nefeon recruitment review</span><label className={`resume-drop ${resume?'has-file':''}`}><input type="file" accept="application/pdf,.pdf" aria-label="Choose resume PDF" onChange={e=>{setResume(e.target.files?.[0]??null);setErrors(prev=>({...prev,resume:''}));}}/><span className="upload-icon"><UploadCloud size={22}/></span><strong>{resume ? resume.name : 'Choose your resume PDF'}</strong><span>{resume ? `${(resume.size/1024/1024).toFixed(2)} MB selected · Click to replace` : 'Click to browse from your device'}</span></label>{errors.resume&&<small className="field-error">{errors.resume}</small>}</div>
                <Field label="Why do you want to join Nefeon?"><textarea rows={4} value={values.motivation} onChange={e=>update('motivation',e.target.value)} placeholder="What interests you about our work and this internship?" maxLength={5000}/>{errors.motivation&&<small className="field-error">{errors.motivation}</small>}</Field>
                <Field label="What skills or value can you contribute?"><textarea rows={4} value={values.contribution} onChange={e=>update('contribution',e.target.value)} placeholder="Tell us what you'd bring to the team…" maxLength={5000}/>{errors.contribution&&<small className="field-error">{errors.contribution}</small>}</Field>
                <Field label="Project, portfolio or achievement" optional><textarea rows={3} value={values.projectHighlight} onChange={e=>update('projectHighlight',e.target.value)} placeholder="Share a project you're proud of…" maxLength={4000}/></Field>
              </div>}
              {step===4 && <div className="fields-stack">
                <Field label="Availability per week"><select value={values.availabilityHours} onChange={e=>update('availabilityHours',e.target.value)}><option value="">Choose weekly hours</option><option>Under 10 hours</option><option>10–20 hours</option><option>20–30 hours</option><option>30–40 hours</option></select>{errors.availabilityHours&&<small className="field-error">{errors.availabilityHours}</small>}</Field>
                <Field label="Additional information" optional><textarea rows={3} value={values.additionalInfo} onChange={e=>update('additionalInfo',e.target.value)} placeholder="Anything else our team should know?" maxLength={4000}/></Field>
                <div className="consent-box"><label className="consent-line"><input type="checkbox" checked={accuracy} onChange={e=>{setAccuracy(e.target.checked);setErrors(prev=>({...prev,accuracy:''}));}}/><span>I confirm that the information provided is accurate to the best of my knowledge.</span></label>{errors.accuracy&&<small className="field-error">{errors.accuracy}</small>}<label className="consent-line"><input type="checkbox" checked={privacy} onChange={e=>{setPrivacy(e.target.checked);setErrors(prev=>({...prev,privacy:''}));}}/><span>I have read the <Link href="/privacy" target="_blank">Nefeon Applicant Privacy Notice</Link> and understand how my information will be used.</span></label>{errors.privacy&&<small className="field-error">{errors.privacy}</small>}</div>
                <div className="privacy-callout"><ShieldCheck size={16}/><p>Do not upload Aadhaar, driving licence, bank details, or other identity documents here. This form is for internship selection only.</p></div>
              </div>}
              <label className="honeypot" aria-hidden="true">Website<input tabIndex={-1} autoComplete="off" value={website} onChange={e=>setWebsite(e.target.value)}/></label>
              {serverError&&<div className="form-server-error" role="alert">{serverError}</div>}
              <div className="form-navigation">{step>0?<button className="back-btn" type="button" onClick={previousStep} disabled={busy}><ArrowLeft size={15}/> Back</button>:<span className="safe-note"><LockKeyhole size={12}/> Your details stay private.</span>}{step<4?<button className="next-btn" type="button" onClick={nextStep}>Next <ArrowRight size={15}/></button>:<button className="next-btn" type="submit" disabled={busy}>{busy?'Submitting securely…':'Submit application'} <ArrowUpRight size={15}/></button>}</div>
            </form>
            <div className="form-frame-footer"><span>NEFEON CAREERS</span><span>© {new Date().getFullYear()} NEFEON</span></div>
          </div>
          <aside className="form-aside"><div className="aside-heading"><span className="aside-number">0{step+1}</span><span>APPLICATION PROGRESS</span></div><div className="timeline">{steps.map((s,i)=><button type="button" key={s.title} className={`timeline-item ${i===step?'active':''} ${i<step?'complete':''}`} onClick={()=>{if(i<=step)setStep(i);}} aria-current={i===step?'step':undefined}><span className="timeline-dot">{i<step?<Check size={14}/>:`0${i+1}`}</span><span className="timeline-copy"><strong>{s.title}</strong><p>{s.note}</p></span></button>)}</div><div className="aside-note"><span className="note-star">✳</span><p>Good work beats a perfect résumé. Tell us what you care about and what you'd like to learn.</p></div><div className="form-trust"><ShieldCheck size={14}/><span>Encrypted in transit · Private resume storage</span></div></aside>
        </div>
      </> : <section className="submission-success"><div className="success-icon"><CheckCircle2 size={34}/></div><p className="section-kicker">APPLICATION RECEIVED</p><h2>Thank you for applying.</h2><p>Your application has been received. Keep the reference below for your records; the team will contact you if there is a next step.</p><div className="reference-card"><span>APPLICATION REFERENCE</span><strong>{submitted.reference}</strong></div>{submitted.emailSent?<p className="email-status"><Mail size={15}/> We sent a confirmation to <strong>{values.email}</strong>. Check your spam folder if it doesn't appear.</p>:<p className="email-status warning"><Mail size={15}/> Your application was saved, but we could not send the confirmation email. Keep your reference number for your records.</p>}<Link className="button-primary" href="/">Return to Nefeon Careers <ArrowUpRight size={15}/></Link></section>}
    </section>
    <footer className="site-footer page-width"><Link href="/" className="footer-brand">NEFEON<span>®</span></Link><div className="footer-copy">Technology, creativity and practical solutions.</div><div className="footer-links"><Link href="/privacy">Applicant privacy</Link><Link href="/admin/login">Team login <ArrowUpRight size={13}/></Link></div></footer>
  </main>;
}
