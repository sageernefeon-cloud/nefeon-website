'use client';

import { FormEvent, useState } from 'react';
import { ArrowLeft, ArrowRight, KeyRound, ShieldCheck, Sparkles } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  async function requestCode(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(''); setNotice('');
    try {
      const response = await fetch('/api/admin/request-otp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: email.trim().toLowerCase() }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? 'Could not request a code.');
      setSent(true); setNotice(result.message ?? 'A sign-in code has been requested. Check your inbox and spam folder.');
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not request a code. Check your configuration.'); }
    finally { setBusy(false); }
  }

  async function verifyCode(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(''); setNotice('');
    try {
      const response = await fetch('/api/admin/verify-otp', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ email: email.trim().toLowerCase(), otp: otp.trim() }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? 'Could not verify the code.');
      router.replace('/admin'); router.refresh();
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not verify the code.'); }
    finally { setBusy(false); }
  }

  return <main className="admin-shell"><header className="admin-topbar"><Link href="/" className="admin-brand"><span className="brand-mark">N</span><span>NEFEON<small>Careers operations</small></span></Link><Link href="/" className="subtle-btn"><ArrowLeft size={14} /> Careers site</Link></header><div className="login-wrap"><section className="login-card"><div className="eyebrow"><span className="eyebrow-dot" /> PRIVATE TEAM PORTAL</div><h1>{sent ? 'Check your inbox.' : 'Welcome back.'}</h1><p>{sent ? `Enter the one-time code sent to ${email}. The code is valid for one sign-in and expires after 10 minutes.` : 'Enter your team email to receive a one-time sign-in code.'}</p>
    {!sent ? <form className="login-form" onSubmit={requestCode}><label className="login-label">Team email address<input className="admin-input" type="email" placeholder="name@nefeon.site" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} /></label><button className="login-submit" disabled={busy}>{busy ? 'Requesting code…' : <>Email me a one-time code <ArrowRight size={15} /></>}</button></form> : <form className="login-form" onSubmit={verifyCode}><label className="login-label">6-digit verification code<input className="admin-input" inputMode="numeric" autoComplete="one-time-code" maxLength={8} placeholder="Enter the code from your email" required value={otp} onChange={e => setOtp(e.target.value)} /></label><button className="login-submit" disabled={busy}>{busy ? 'Verifying…' : <>Verify and continue <ArrowRight size={15} /></>}</button><button className="outline-btn" type="button" onClick={() => { setSent(false); setOtp(''); setError(''); setNotice(''); }}><ArrowLeft size={14} /> Use a different email</button></form>}
    {error && <div className="error-banner" role="alert">{error}</div>}{notice && <div className="success-banner" role="status">{notice}</div>}
    <div className="login-foot"><ShieldCheck size={14} style={{verticalAlign:'middle',marginRight:6}} />Access is restricted to allowlisted staff. One-time sign-in codes are sent directly through Resend; Supabase is used for the application database and private file storage.</div>
    <div className="login-foot"><KeyRound size={14} style={{verticalAlign:'middle',marginRight:6}} />If the code does not arrive, check your inbox and spam folder. The address must be listed in the server’s STAFF_EMAILS setting.</div>
    </section></div></main>;
}
